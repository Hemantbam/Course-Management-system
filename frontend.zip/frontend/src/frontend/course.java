package frontend;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JComboBox;
import javax.swing.ButtonModel;
import javax.swing.ComboBoxModel;
import javax.swing.DefaultComboBoxModel;
import javax.swing.SpringLayout;
import javax.swing.JCheckBox;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import java.awt.Color;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.ImageIcon;
import javax.swing.JSeparator;
import javax.swing.border.MatteBorder;
import javax.swing.border.TitledBorder;
import javax.swing.border.EtchedBorder;
import javax.swing.border.CompoundBorder;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JScrollPane;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.border.BevelBorder;

public class course extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JTextField courseNameTextField;
	private JTextField courseDescriptionTextField;
	private JLabel lblNoOfModules;
	private JTextField noOfModulesTextField;
	private JTextField lengthOfTheCourseTextField;
	private JLabel lblLengthOfThe;
	private JLabel lblNewLabel_1;
	private JCheckBox courseActivatedCheckBox;
	private JComboBox courseLevelcomboBox;
	private String courseName = "";
	private String courseDescription = "";
	private String lengthOfTheCourse = "";
	private String noOfModules = "";
	private String courseLevel = "";
	private String isCourseActivated = "";
	private static DefaultTableModel courseDefaultTableModel =new DefaultTableModel(
			new Object[][] {
				{null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null},
			},
			new String[] {
				"ID", "Name", "Description", "No of Module ", "Level", "Length", "Active Status"
			}
			
		);
	/**
	 * Launch the application.
	 */public static void main(String[] args) {
			try {
				course dialog = new course("Add", 0);
				dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
				dialog.setVisible(true);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}


	public JTextField getCourseNameTextField() {
		return courseNameTextField;
	}


	public JTextField getCourseDescriptionTextField() {
		return courseDescriptionTextField;
	}


	public JTextField getLengthOfTheCourseTextField() {
		return lengthOfTheCourseTextField;
	}



	public JTextField getNoOfModulesTextField() {
		return noOfModulesTextField;
	}


	public String getIsCourseActivated() {
		return isCourseActivated;
	}

	
	public String getCourseLevel() {
		return courseLevel;
	}


	/**
	 * Create the dialog.
	 */
	 public static void showCourseDataInJtableFromDb() {

			// Connection con; con = dbConn.getConnection();
			Statement statement = dbConn.getStatement();

			String selectQuery = "SELECT * FROM `coursedata`";

			ResultSet resultSet;
			try {
				resultSet = statement.executeQuery(selectQuery);
				courseDefaultTableModel.setRowCount(0);
				while (resultSet.next()) {
					int idFromDb = resultSet.getInt("Id");
					// varchar getString()
					// bigint getBigDecimal()
					// date getDate()
					String nameFromDb = resultSet.getString("c_Name");
					String descriptionFromDb = resultSet.getString("c_desc");
					String moduleNumberFromDb = resultSet.getString("no_OfModule");
					String courseLevelFromDb = resultSet.getString("c_Level");
					String courseLengthFromDb = resultSet.getString("Length_OFC");
					String activeStatusFromDb = resultSet.getString("active_Status");

					courseDefaultTableModel.addRow(new Object[] { idFromDb, nameFromDb, descriptionFromDb, moduleNumberFromDb,
							courseLevelFromDb, courseLengthFromDb, activeStatusFromDb});
					
				}

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
	public course(String action, int id) {
		setTitle("Course Form");
		setVisible(true);
		setBounds(100, 100, 601, 397);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(null);
		getContentPane().add(contentPanel, BorderLayout.CENTER);

		JLabel lblNewLabel = new JLabel("Course Name\r\n");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel.setBounds(185, 78, 94, 13);

		courseNameTextField = new JTextField();
		courseNameTextField.setBounds(312, 72, 268, 30);
		courseNameTextField.setColumns(10);

		JLabel lblCourseDescription = new JLabel("Course Description\r\n\r\n");
		lblCourseDescription.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblCourseDescription.setBounds(185, 111, 125, 35);

		courseDescriptionTextField = new JTextField();
		courseDescriptionTextField.setBounds(312, 110, 268, 29);
		courseDescriptionTextField.setColumns(10);

		lblNoOfModules = new JLabel("No Of Modules");
		lblNoOfModules.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNoOfModules.setBounds(185, 155, 109, 13);

		noOfModulesTextField = new JTextField();
		noOfModulesTextField.setBounds(312, 149, 50, 29);
		noOfModulesTextField.setColumns(10);

		lengthOfTheCourseTextField = new JTextField();
		lengthOfTheCourseTextField.setBounds(418, 228, 72, 29);
		lengthOfTheCourseTextField.setColumns(10);

		lblLengthOfThe = new JLabel("Length of the Course\r\n(in Years)\r\n");
		lblLengthOfThe.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblLengthOfThe.setBounds(185, 227, 213, 29);

		lblNewLabel_1 = new JLabel("Course Level");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_1.setBounds(185, 188, 94, 29);

		JComboBox courseLevelcomboBox = new JComboBox();
		courseLevelcomboBox.setFont(new Font("Tahoma", Font.PLAIN, 15));
		courseLevelcomboBox.setBounds(312, 187, 178, 31);
		courseLevelcomboBox.setModel(new DefaultComboBoxModel(new String[] {"Select course type", "UnderGraduate", "PostGraduate"}));
		contentPanel.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBorder(new BevelBorder(BevelBorder.RAISED, new Color(0, 0, 0), null, null, null));
		panel.setBounds(0, 0, 151, 371);
		panel.setLayout(null);
		panel.setBackground(new Color(64, 0, 128));
		contentPanel.add(panel);
		
		JLabel lblNewLabel_2 = new JLabel("");
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2.setIcon(new ImageIcon(course.class.getResource("/Image/icon form.png")));
		lblNewLabel_2.setBounds(10, 88, 131, 130);
		panel.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("CMS");
		lblNewLabel_3.setForeground(new Color(255, 255, 255));
		lblNewLabel_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 30));
		lblNewLabel_3.setBounds(10, 0, 131, 78);
		panel.add(lblNewLabel_3);
		
		JLabel lblNewLabel_5 = new JLabel("Course Details");
		lblNewLabel_5.setForeground(new Color(255, 255, 255));
		lblNewLabel_5.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_5.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_5.setBounds(0, 238, 151, 23);
		panel.add(lblNewLabel_5);
		contentPanel.add(lblNoOfModules);
		contentPanel.add(lblNewLabel_1);
		contentPanel.add(courseLevelcomboBox);
		contentPanel.add(noOfModulesTextField);
		contentPanel.add(lblLengthOfThe);
		contentPanel.add(lengthOfTheCourseTextField);
		contentPanel.add(lblCourseDescription);
		contentPanel.add(lblNewLabel);
		contentPanel.add(courseNameTextField);
		contentPanel.add(courseDescriptionTextField);

		JCheckBox courseActivatedCheckBox = new JCheckBox("Activated");
		courseActivatedCheckBox.setFont(new Font("Tahoma", Font.PLAIN, 15));
		courseActivatedCheckBox.setBounds(312, 262, 125, 41);
		contentPanel.add(courseActivatedCheckBox);

		JButton addCourseButton = new JButton(action);
		addCourseButton.setBackground(new Color(0, 255, 0));
		addCourseButton.setFont(new Font("Tahoma", Font.BOLD, 18));
		addCourseButton.setBounds(312, 309, 167, 35);
		addCourseButton.setActionCommand("AddCourse");
		addCourseButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (e.getActionCommand().equals("AddCourse")) {
					// Get the Course Form data
					courseName = courseNameTextField.getText().trim();
					courseDescription = courseDescriptionTextField.getText().trim();
					lengthOfTheCourse = lengthOfTheCourseTextField.getText().trim();
					noOfModules = noOfModulesTextField.getText().trim();
					ComboBoxModel courseLevelBoxModel = courseLevelcomboBox.getModel();
					courseLevel = courseLevelBoxModel.getSelectedItem().toString();

					if (courseActivatedCheckBox.isSelected()) {
						isCourseActivated = "YES";
					} else {
						isCourseActivated = "NO";
					}

					// Write the SQL insert query
					if(action == "Add") {
					String insertQuery = "INSERT INTO `coursedata`"
							+ " (`ID`, `c_Name`, `c_desc`, `no_OfModule`, `Length_OfC`, `c_Level`, `active_Status`) "
							+ "VALUES (NULL, '" + courseName + "', '" + courseDescription + "', '" + noOfModules
							+ "', '" + lengthOfTheCourse + "', '" + courseLevel + "', '" + isCourseActivated + "')";

					// Execute the SQL insert query
					Statement statement = dbConn.getStatement();

					try {
						int insertSuccess = statement.executeUpdate(insertQuery);
						if (insertSuccess == 1) {
							JOptionPane.showMessageDialog(contentPanel, "Saved into database!");
						}
						course.showCourseDataInJtableFromDb();
					} catch (SQLException e1) {
						e1.printStackTrace();
					}
					

					/*
					 * //Refresh the JTable sync with Database table data
					 * adminFrontend.showTeacherDataInJtableFromDb();
					 * 
					 * //Close the course adminFrontend.course.setVisible(false);
					 */

					}else if(action == "Update") {
						String updateDB = "UPDATE `coursedata` SET `c_Name`='" + courseName + "',`c_desc`='" + courseDescription + "',`no_OfModule`='" + noOfModules + "',`Length_OfC`='" + lengthOfTheCourse + "',`active_Status`= '" + isCourseActivated + "' WHERE `ID`='"+ id+ "'";
						Statement statement2 = dbConn.getStatement();
					try {
						int updateSuccess = statement2.executeUpdate(updateDB);
						if(updateSuccess == 1) {
							JOptionPane.showMessageDialog(contentPanel, "Updated into database!");
							dispose();
						}
						course.showCourseDataInJtableFromDb();
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}	
				}
				}
				adminFrontend.showCourseTable();
			}
		});
		contentPanel.add(addCourseButton);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBounds(154, 0, 438, 41);
		panel_1.setBackground(Color.BLACK);
		contentPanel.add(panel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("Add Course Form");
		lblNewLabel_1_1.setForeground(Color.WHITE);
		lblNewLabel_1_1.setFont(new Font("Tahoma", Font.BOLD, 25));
		panel_1.add(lblNewLabel_1_1);
		
		JSeparator separator = new JSeparator();
		separator.setOrientation(SwingConstants.VERTICAL);
		separator.setForeground(new Color(128, 128, 192));
		separator.setBackground(Color.BLACK);
		separator.setBounds(602, 0, 10, 361);
		contentPanel.add(separator);
		
		JSeparator separator_1 = new JSeparator();
		separator_1.setForeground(new Color(128, 128, 192));
		separator_1.setBackground(Color.BLACK);
		separator_1.setBounds(148, 359, 456, 2);
		contentPanel.add(separator_1);
		
		course.showCourseDataInJtableFromDb();
		}
}