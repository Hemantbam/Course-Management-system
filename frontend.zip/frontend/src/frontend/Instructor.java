package frontend;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.ImageIcon;
import javax.swing.JTable;
import java.awt.CardLayout;
import javax.swing.table.DefaultTableModel;
import javax.swing.JScrollPane;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class Instructor {

	private JFrame frmInstructor;
	private JTextField nametextField;
	private JTextField moduletextfield;
	private String username="";
	private String course="";
	private String Module="";
	private static int  AIDFromDb ;
	private JTextField MobiletextField;
	String Name="";
	static String moduleFromDB="";
	private CardLayout cl_panel_1 = new CardLayout(0, 0);
	Statement statement = dbConn.getStatement();
	private JPanel panel_1;
	private JTable table;
	
	private static DefaultTableModel submittedAddignmentDefaultTableModel = new DefaultTableModel(
			new Object[][] {
				{null,null, null, null, null, null, null},
				{null,null, null, null, null, null, null},
			},
			new String[] {
					"A_ID","Name", "Student_Username", "Marks", "Question", "Answer", "Module"
			}
		);

	public JTextField getNametextField() {
		return nametextField;
	}

	public JTextField getModuletextfield() {
		return moduletextfield;
	}

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Instructor window = new Instructor(null);
					window.frmInstructor.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public static void showTeacherDataInJtableFromDb() {

		// Connection con; con = dbConn.getConnection();
		Statement statement = dbConn.getStatement();
		
		String selectQuery = "SELECT * FROM `submittedassignment` WHERE moduleName='" + moduleFromDB + "'";

		ResultSet resultSet;
		try {
			resultSet = statement.executeQuery(selectQuery);
			submittedAddignmentDefaultTableModel.setRowCount(0);
			while (resultSet.next()) {
				// varchar getString()
				// bigint getBigDecimal()
				// date getDate()
				AIDFromDb = resultSet.getInt("Id");
				String studentUsernameFromDb = resultSet.getString("studentUsername");
				String studentNameFromDb = resultSet.getString("studentName");
				int  marksFromDb = resultSet.getInt("marks");
				String questionAssignedFromDb = resultSet.getString("question");
				String answerFromDb = resultSet.getString("answer");
				String moduleNameDb = resultSet.getString("moduleName");

				submittedAddignmentDefaultTableModel.addRow(new Object[] { AIDFromDb, studentNameFromDb ,studentUsernameFromDb, marksFromDb, questionAssignedFromDb,
						answerFromDb, moduleNameDb });

				

			}
			

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


	}
	public JFrame getFrmInstructor() {
		return frmInstructor;
	}
		public static void TeacherDetails() {

		}

	
	public Instructor(String UserId) {
		initialize(UserId);
	} 

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize(String UserId) {
		String mobileNumber=UserId;
		try {
			String searchQuery= "SELECT  Name,Module_Assigned  FROM `techer` WHERE mobileNumber='"+ mobileNumber + "'";
			ResultSet resultSet = statement.executeQuery(searchQuery);
			resultSet.next();
			Name = resultSet.getString("Name");
			moduleFromDB = resultSet.getString("Module_Assigned");
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		frmInstructor = new JFrame();
		frmInstructor.setTitle("Instructor");
		frmInstructor.setBounds(100, 100, 717, 483);
		frmInstructor.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmInstructor.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(64, 0, 128));
		panel.setBounds(0, 10, 180, 436);
		frmInstructor.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Instructor");
		lblNewLabel.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel.setForeground(new Color(255, 255, 255));
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 25));
		lblNewLabel.setBounds(20, 179, 137, 40);
		panel.add(lblNewLabel);
		
		JLabel lblNewLabel_2 = new JLabel("Name");
		lblNewLabel_2.setForeground(Color.WHITE);
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_2.setBounds(10, 249, 48, 26);
		panel.add(lblNewLabel_2);
		
		JButton btnNewButton_1_2_1_1 = new JButton("Logout");
		btnNewButton_1_2_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmInstructor.dispose();
				new frontendApp();
			}
		});
		btnNewButton_1_2_1_1.setBounds(61, 361, 93, 26);
		panel.add(btnNewButton_1_2_1_1);
		
		JLabel lblNewLabel_3 = new JLabel("");
		lblNewLabel_3.setIcon(new ImageIcon(Instructor.class.getResource("/Image/Teacher.png")));
		lblNewLabel_3.setBounds(24, 10, 156, 159);
		panel.add(lblNewLabel_3);
		
		JLabel lblNewLabel_2_1 = new JLabel("Module");
		lblNewLabel_2_1.setForeground(Color.WHITE);
		lblNewLabel_2_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_2_1.setBounds(10, 284, 58, 26);
		panel.add(lblNewLabel_2_1);
		
		nametextField = new JTextField();
		nametextField.setFont(new Font("Tahoma", Font.BOLD, 12));
		nametextField.setBounds(61, 255, 109, 19);
		panel.add(nametextField);
		nametextField.setColumns(10);
		nametextField.setText(Name);
		
		moduletextfield = new JTextField();
		moduletextfield.setFont(new Font("Tahoma", Font.BOLD, 12));
		moduletextfield.setColumns(10);
		moduletextfield.setBounds(61, 290, 109, 19);
		panel.add(moduletextfield);
		moduletextfield.setText(moduleFromDB);
		
		
		
		JLabel lblNewLabel_4 = new JLabel("Mobile");
		lblNewLabel_4.setForeground(new Color(255, 255, 255));
		lblNewLabel_4.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel_4.setBounds(13, 325, 45, 13);
		panel.add(lblNewLabel_4);
		
		MobiletextField = new JTextField();
		MobiletextField.setFont(new Font("Tahoma", Font.BOLD, 12));
		MobiletextField.setColumns(10);
		MobiletextField.setBounds(61, 320, 109, 19);
		panel.add(MobiletextField);
		MobiletextField.setText(UserId);
		
		JPanel panel_2 = new JPanel();
		panel_2.setLayout(null);
		panel_2.setBackground(Color.BLACK);
		panel_2.setBounds(188, 10, 505, 49);
		frmInstructor.getContentPane().add(panel_2);
		
		JLabel lblNewLabel_1 = new JLabel("Welcome Instructor");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setForeground(Color.WHITE);
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblNewLabel_1.setBackground(Color.BLACK);
		lblNewLabel_1.setBounds(10, 10, 485, 21);
		panel_2.add(lblNewLabel_1);
		
		JPanel panel_2_1_2_1_1_1 = new JPanel();
		panel_2_1_2_1_1_1.setLayout(null);
		panel_2_1_2_1_1_1.setForeground(Color.LIGHT_GRAY);
		panel_2_1_2_1_1_1.setBackground(Color.LIGHT_GRAY);
		panel_2_1_2_1_1_1.setBounds(190, 69, 503, 63);
		frmInstructor.getContentPane().add(panel_2_1_2_1_1_1);
		
		JButton btnNewButton_1_2_2_1_1_2 = new JButton("Mark Assignment");
		
		btnNewButton_1_2_2_1_1_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			cl_panel_1.show(panel_1, "name_58177384692300");
			}
		});
		btnNewButton_1_2_2_1_1_2.setBounds(155, 10, 133, 25);
		panel_2_1_2_1_1_1.add(btnNewButton_1_2_2_1_1_2);
		
		JButton btnNewButton_1_2_2_1_1_2_1 = new JButton("Add Assignment");
		btnNewButton_1_2_2_1_1_2_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new teacherAssignment(moduleFromDB , Name);
			}
		});
		btnNewButton_1_2_2_1_1_2_1.setBounds(10, 10, 133, 25);
		panel_2_1_2_1_1_1.add(btnNewButton_1_2_2_1_1_2_1);
		
		JButton btnNewButton_1_2_2_1_1 = new JButton("View Students");
		btnNewButton_1_2_2_1_1.setBounds(307, 10, 133, 25);
		panel_2_1_2_1_1_1.add(btnNewButton_1_2_2_1_1);
		
		panel_1 = new JPanel();
		panel_1.setBounds(190, 142, 503, 294);
		frmInstructor.getContentPane().add(panel_1);
		panel_1.setLayout(cl_panel_1);
		
		JPanel panel_3 = new JPanel();
		panel_1.add(panel_3, "name_58177375861900");
		
		JPanel panel_4 = new JPanel();
		panel_4.setBackground(new Color(0, 0, 0));
		panel_1.add(panel_4, "name_58177384692300");
		panel_4.setLayout(null);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(24, 35, 448, 167);
		panel_4.add(scrollPane_1);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane_1.setViewportView(scrollPane);
		
		table = new JTable();
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				Object[] options = { "Add Marks", "Back" };
				int n = JOptionPane.showOptionDialog(null, "Do you want to Add Marks ",
						"Add Marks ", JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null,
						options, options[0]);
				if (n == 0) {
					int id = Integer.parseInt(table.getValueAt(table.getSelectedRow(), 0).toString());
					System.out.println(id);
					addMarks addmarks = new  addMarks();
					String IdFromDb = "";
					String nameFromDb = "";
					int selectedRowNo = table.getSelectedRow();
					for (int columnIndex = 0; columnIndex < table.getColumnCount(); columnIndex++) {
						if (IdFromDb.isEmpty()) {
							IdFromDb = table.getValueAt(table.getSelectedRow(), columnIndex).toString();
						}else if (nameFromDb.isEmpty()) {
							nameFromDb = table.getValueAt(table.getSelectedRow(), columnIndex).toString();
						}
					}
					addMarks.getAssignmentId().setText(IdFromDb);
					addMarks.getNametextField().setText(nameFromDb);

				}
				
				
				
			}
		});
		scrollPane.setViewportView(table);
		table.setModel(submittedAddignmentDefaultTableModel);
		
		JLabel lblNewLabel_5 = new JLabel("Assignment Details:");
		lblNewLabel_5.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel_5.setForeground(new Color(255, 255, 255));
		lblNewLabel_5.setBounds(24, 10, 241, 25);
		panel_4.add(lblNewLabel_5);
		
		JPanel panel_5 = new JPanel();
		panel_1.add(panel_5, "name_58177393017400");
		btnNewButton_1_2_2_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new viewStudent();
			}
		});
		
		Instructor.showTeacherDataInJtableFromDb();
	}
}
