package frontend;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JTextField;
import java.awt.Color;
import javax.swing.SwingConstants;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class teacherAssignment extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JTextField questionTextField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			teacherAssignment dialog = new teacherAssignment(null, null);
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public teacherAssignment(String module, String Name) {
		String modulName=module;
		String t_name=Name;
		setVisible(true);
		setBounds(100, 100, 668, 445);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		{
			JLabel lblNewLabel = new JLabel("Questions :");
			lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 15));
			lblNewLabel.setBounds(182, 92, 107, 38);
			contentPanel.add(lblNewLabel);
		}
		
		questionTextField = new JTextField();
		questionTextField.setBounds(282, 79, 362, 69);
		contentPanel.add(questionTextField);
		questionTextField.setColumns(10);
		
		JPanel panel_1 = new JPanel();
		panel_1.setLayout(null);
		panel_1.setBackground(new Color(64, 0, 128));
		panel_1.setBounds(0, 0, 173, 408);
		contentPanel.add(panel_1);
		
		JLabel lblAssignment = new JLabel("Assignment");
		lblAssignment.setHorizontalAlignment(SwingConstants.CENTER);
		lblAssignment.setForeground(Color.WHITE);
		lblAssignment.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblAssignment.setBounds(10, 193, 153, 48);
		panel_1.add(lblAssignment);
		
		JLabel lblNewLabel_4 = new JLabel("");
		lblNewLabel_4.setIcon(new ImageIcon(teacherAssignment.class.getResource("/Image/icon form.png")));
		lblNewLabel_4.setBounds(30, 60, 115, 123);
		panel_1.add(lblNewLabel_4);
		
		JPanel panel_2 = new JPanel();
		panel_2.setLayout(null);
		panel_2.setBackground(Color.BLACK);
		panel_2.setBounds(182, 0, 472, 49);
		contentPanel.add(panel_2);
		
		JLabel lblNewLabel_1 = new JLabel("Assignment Upload");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setForeground(Color.WHITE);
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblNewLabel_1.setBackground(Color.BLACK);
		lblNewLabel_1.setBounds(10, 0, 452, 49);
		panel_2.add(lblNewLabel_1);
		
		Statement statement = dbConn.getStatement();
//		String selectQuery = "SELECT m_Name FROM `moduledata`";
//		try {
//			ResultSet resultSet = statement.executeQuery(selectQuery);
//			while(resultSet.next()) {
//				assignedModulecomboBox.addItem(resultSet.getString("m_Name"));
//
//			}
//			
//		} catch (SQLException e) {
//			e.printStackTrace();
//		}
		
		JLabel lblNewLabel_2 = new JLabel("Module :");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel_2.setBounds(182, 166, 93, 30);
		contentPanel.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Uploaded By: ");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_3.setBounds(182, 219, 93, 30);
		contentPanel.add(lblNewLabel_3);
		

		
		JButton btnNewButton = new JButton("Upload");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String questions = questionTextField.getText().toString();
				String uploadByName = "";
				String insertQueryInUserAccount = "INSERT INTO `assignment`(`question`, `moduleName`,`uploadedBy`) VALUES ('"+questions+"','"+modulName+"','"+t_name+"')";
				
				try {
					int n=statement.executeUpdate(insertQueryInUserAccount);
					if(n==1) {
					JOptionPane.showMessageDialog(contentPanel, "Successfully Assignment uploaded");
					}
					dispose();
				
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
				dispose();
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 13));
		btnNewButton.setBounds(457, 324, 141, 40);
		contentPanel.add(btnNewButton);
		
		JLabel moduleNameTextField = new JLabel("");
		moduleNameTextField.setBounds(282, 168, 362, 30);
		contentPanel.add(moduleNameTextField);
		moduleNameTextField.setText(module);
		
		JLabel uploadedBy = new JLabel("");
		uploadedBy.setBounds(282, 220, 203, 30);
		contentPanel.add(uploadedBy);
		uploadedBy.setText(Name);
	}
}
