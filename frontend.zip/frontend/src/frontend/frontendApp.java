package frontend;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.SwingConstants;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.event.ActionEvent;

public class frontendApp extends JFrame {
	private JFrame frmfronend;
	private JPanel contentPane;
	private static JTextField usernameField;
	//private static String name="";
	private JPasswordField passwordField;
	static String valueFromComboxBox = "";
	private JLabel lblNewLabel_4;
	public static String userID="";

	private static final frontendApp frame  =new frontendApp();


	public static JTextField getUsernameField() {
		return usernameField;
	}

	public JPasswordField getPasswordField() {
		return passwordField;
	}
	

	public static void setUsernameField(JTextField usernameField) {
		frontendApp.usernameField = usernameField;
	}
	

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */

	
	
	public JFrame getFrmlogin() {
		
		return frmfronend;
	}
	
	public frontendApp() {
		setVisible(true);
		setTitle("Course Management System");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 693, 466);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(64, 0, 128));
		panel.setBounds(0, 10, 251, 424);
		contentPane.add(panel);
		
		JLabel lblNewLabel_5 = new JLabel("");
		lblNewLabel_5.setIcon(new ImageIcon(frontendApp.class.getResource("/Image/c.png")));
		panel.add(lblNewLabel_5);
		
		lblNewLabel_4 = new JLabel("Course Management System");
		lblNewLabel_4.setForeground(new Color(255, 255, 255));
		lblNewLabel_4.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4.setVerticalAlignment(SwingConstants.BOTTOM);
		lblNewLabel_4.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNewLabel_4.setHorizontalTextPosition(SwingConstants.LEADING);
		panel.add(lblNewLabel_4);
		
		JLabel lblNewLabel = new JLabel("Welcome User ");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setVerticalAlignment(SwingConstants.TOP);
		lblNewLabel.setOpaque(true);
		lblNewLabel.setBackground(new Color(0, 0, 0));
		lblNewLabel.setForeground(new Color(255, 255, 255));
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 25));
		lblNewLabel.setBounds(254, 10, 415, 36);
		contentPane.add(lblNewLabel);
		
		usernameField = new JTextField();
		usernameField.setBounds(378, 127, 143, 19);
		contentPane.add(usernameField);
		usernameField.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("Username");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_1.setBounds(274, 133, 106, 13);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Password");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_2.setBounds(274, 174, 79, 13);
		contentPane.add(lblNewLabel_2);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(378, 173, 143, 19);
		contentPane.add(passwordField);
		
		JLabel lblNewLabel_3 = new JLabel("User Type");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_3.setBounds(274, 227, 79, 22);
		contentPane.add(lblNewLabel_3);
		
		JComboBox comboBox1 = new JComboBox();
		comboBox1.setFont(new Font("Tahoma", Font.PLAIN, 16));
		comboBox1.setModel(new DefaultComboBoxModel(new String[] {"Admin", "Student", "Instructor"}));
		comboBox1.setBounds(378, 229, 143, 19);
		contentPane.add(comboBox1);
		
		
		
		JButton btnNewButton = new JButton("Login");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				userID=usernameField.getText();
				String username = usernameField.getText().trim();
				String password = String.valueOf(passwordField.getPassword());
				String userType = comboBox1.getSelectedItem().toString();

				// Check in UserAccount table

				String checkQuery = "SELECT * FROM `useraccount` " + "WHERE mobileNumber = '" + username + "' "
						+ "AND password = '" + password + "' " + "AND UserType='" + userType + "' ";

				Statement statement = dbConn.getStatement();
				if(userType =="Student") {
					try {
						ResultSet resultSet = statement.executeQuery(checkQuery);
						if (resultSet.next()) {

							studentFrontend StudentFrontend = new studentFrontend(userID);
							StudentFrontend.getFrmStudent().setVisible(true);
							frame.setVisible(false);
						} else {
							JOptionPane.showMessageDialog(frmfronend, "Username or password is wrong!");
						}
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace(); 
					}
				}

				if(userType =="Admin") {
				try {
					ResultSet resultSet = statement.executeQuery(checkQuery);
					if (resultSet.next()) {
						adminFrontend AdminFrontend = new adminFrontend();
						AdminFrontend.getFrmAdmin().setVisible(true);
						frame.setVisible(false);
					} else {
						JOptionPane.showMessageDialog(frmfronend, "Username or password is wrong!");
					}
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
				if(userType =="Instructor") {
				try {
					ResultSet resultSet = statement.executeQuery(checkQuery);
					if (resultSet.next()) {
						Instructor Instructor = new Instructor(userID);
						Instructor.getFrmInstructor().setVisible(true);
						frame.setVisible(false);
					} else {
						JOptionPane.showMessageDialog(frmfronend, "Username or password is wrong!");
						dispose();
					}
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					
					e1.printStackTrace();
				}
			}
					dispose();
			}
			
			
			
			
		});
		btnNewButton.setBackground(new Color(128, 255, 128));
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 16));
		btnNewButton.setBounds(378, 304, 99, 36);
		contentPane.add(btnNewButton);
		
		JButton btnSignup = new JButton("Sign up");
		btnSignup.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new registration();
			}
		});
		btnSignup.setFont(new Font("Tahoma", Font.BOLD, 16));
		btnSignup.setBackground(new Color(128, 255, 128));
		btnSignup.setBounds(378, 358, 99, 36);
		contentPane.add(btnSignup);
		Instructor instructor = new Instructor(userID);
//		frontendApp.details();


		}
	
}
