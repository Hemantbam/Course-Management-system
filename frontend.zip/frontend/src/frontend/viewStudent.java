package frontend;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.SwingConstants;
import javax.swing.ImageIcon;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JScrollPane;

public class viewStudent extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JTable table;
	private static DefaultTableModel studentDefaultTableModel =new DefaultTableModel(
			new Object[][] {
				{null, null, null, null},
				{null, null, null, null},
				{null, null, null, null},
				{null, null, null, null},
				{null, null, null, null},
				{null, null, null, null},
				{null, null, null, null},
				{null, null, null, null},
			},
			new String[] {
				"Studnet ID", "Name", "Course", "Level"
			}
		);

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			viewStudent dialog = new viewStudent();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public viewStudent() {
		initialize();
	}
	
	public static void showstudentDataInJtableFromDb(){
		 
		  //Connection con; con = dbConn.getConnection();
			  Statement statement = dbConn.getStatement();

				String selectQuery = "SELECT * FROM `studentdata`";

				ResultSet resultSet;
				try {
					resultSet = statement.executeQuery(selectQuery);
					studentDefaultTableModel.setRowCount(0);
					while (resultSet.next()) {
						// varchar getString()
						// bigint getBigDecimal()
						// date getDate()
						String s_NameFromDb = resultSet.getString("s_Name");
						String courseFromDb = resultSet.getString("c_Enrolled");
						String s_LevelfromDB = resultSet.getString("s_Level");
						int idFromDb = resultSet.getInt("s_ID");

						studentDefaultTableModel.addRow(new Object[] { idFromDb, s_NameFromDb, courseFromDb,
								s_LevelfromDB});

					}
					
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
	}
				
				
	private void initialize() {
		setVisible(true);
		setBounds(100, 100, 592, 441);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		
		JPanel panel_2 = new JPanel();
		panel_2.setLayout(null);
		panel_2.setBackground(Color.BLACK);
		panel_2.setBounds(183, 0, 385, 49);
		contentPanel.add(panel_2);
		
		JLabel lblNewLabel_1 = new JLabel("Student Details");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setForeground(Color.WHITE);
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblNewLabel_1.setBackground(Color.BLACK);
		lblNewLabel_1.setBounds(10, 0, 365, 49);
		panel_2.add(lblNewLabel_1);
		
		JPanel panel_1 = new JPanel();
		panel_1.setLayout(null);
		panel_1.setBackground(new Color(64, 0, 128));
		panel_1.setBounds(0, 0, 173, 394);
		contentPanel.add(panel_1);
		
		JLabel lblNewLabel = new JLabel("Student");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblNewLabel.setBounds(26, 159, 115, 48);
		panel_1.add(lblNewLabel);
		
		JLabel lblNewLabel_4 = new JLabel("");
		lblNewLabel_4.setIcon(new ImageIcon(viewStudent.class.getResource("/Image/student.png")));
		lblNewLabel_4.setBounds(26, 10, 115, 123);
		panel_1.add(lblNewLabel_4);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(194, 72, 359, 306);
		contentPanel.add(scrollPane_1);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane_1.setViewportView(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		table.setModel(studentDefaultTableModel);
		table.getColumnModel().getColumn(0).setPreferredWidth(64);
		table.getColumnModel().getColumn(2).setPreferredWidth(56);
		viewStudent.showstudentDataInJtableFromDb();
	}
}
