package frontend;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.Font;
import java.awt.Window;

import javax.swing.SwingConstants;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import javax.swing.JRadioButton;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;

public class studentFrontend {

	private JFrame frmStudent;
	private JTable table;
	private static DefaultTableModel moduleDefaultTableModel =new DefaultTableModel(
			new Object[][] {
				{null, null, null, null, null, null},
				{null, null, null, null, null, null},
				{null, null, null, null, null, null},
			},
			new String[] {
				"Module", "Course", "Level", "Semester", "Credit Value", "Is Optional"
			}
		);
	private static DefaultTableModel teacherModuleDefaultTableModelnew =new DefaultTableModel(
			new Object[][] {
				{null, null, null},
				{null, null, null},
				{null, null, null},
			},
			new String[] {
				"Module", "Teacher", "is PartTime"
			}
		);
	private JTable table_1;
	private JTextField idfield;
	private JTextField namefield;
	private JTextField semfield;
	private JTextField levelfield;
	String Name="";
	String level="";
	String sem="";
	public static String mobileNumber="";
	

	public JFrame getFrmStudent() {
		return frmStudent;
	}

	/**
	 * Launch the application.
	 */
	  
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					studentFrontend window = new studentFrontend(null);
					window.frmStudent.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public studentFrontend(String userID) {
		//globalID = id;
		initialize(userID);
	}
	public static void showModuleDataInJtableFromDb(){
		 
		  //Connection con; con = dbConn.getConnection();
			  Statement statement = dbConn.getStatement();

				String selectQuery = "SELECT * FROM `moduledata`";
				String teacherQuery="SELECT * FROM `techer`";

				ResultSet resultSet;
				try {
					resultSet = statement.executeQuery(selectQuery);
					moduleDefaultTableModel.setRowCount(0);
					while (resultSet.next()) {
						// varchar getString()
						// bigint getBigDecimal()
						// date getDate()
						String m_NameFromDb = resultSet.getString("m_Name");
						String courseNameFromDb = resultSet.getString("courseName");
						String levelFromDb = resultSet.getString("level");
						String semFromDb = resultSet.getString("sem");
						int creditValueFromDb = resultSet.getInt("creditValue");
						String isoptionalModuleFromDb = resultSet.getString("optionalModule");

						moduleDefaultTableModel.addRow(new Object[] { m_NameFromDb, courseNameFromDb, levelFromDb,
								semFromDb, creditValueFromDb, isoptionalModuleFromDb });

//						System.out.println(idFromDb);
//						System.out.println(nameFromDb);
//						System.out.println(addressFromDb);
//						System.out.println(genderFromDb);
//						System.out.println(moduleAssignedFromDb);
//						System.out.println(dateFromDb);
//						System.out.println(isPartTimeFromDb);
//						System.out.println("----------------------------------");

					}

				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				try {
					resultSet = statement.executeQuery(teacherQuery);
					teacherModuleDefaultTableModelnew.setRowCount(0);
					while (resultSet.next()) {
						// varchar getString()
						// bigint getBigDecimal()
						// date getDate()
						String nameFromDb = resultSet.getString("Name");
						String moduleAssignedFromDb = resultSet.getString("Module_Assigned");
						String isPartTimeFromDb = resultSet.getString("is_PartTime");

						teacherModuleDefaultTableModelnew.addRow(new Object[] {moduleAssignedFromDb, nameFromDb, 
								isPartTimeFromDb });
					}
				} catch (Exception e) {
					// TODO: handle exception
					e.printStackTrace();
				}

	}
	
				
	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize(String userID) {
		
		 mobileNumber=userID;
		try {
			Statement statement = dbConn.getStatement();
			String searchQuery= "SELECT  s_Name,Semester,s_level  FROM `studentdata` WHERE mobileNumber='"+ mobileNumber + "'";
			ResultSet resultSet = statement.executeQuery(searchQuery);
			resultSet.next();
			Name = resultSet.getString("s_Name");
			level = resultSet.getString("s_level");
			sem = resultSet.getString("Semester");
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		frmStudent = new JFrame();
		frmStudent.setTitle("Student");
		frmStudent.setBounds(100, 100, 708, 446);
		frmStudent.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JPanel panel = new JPanel();
		frmStudent.getContentPane().add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(64, 0, 128));
		panel_1.setBounds(0, 10, 191, 407);
		panel.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Student");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setForeground(new Color(255, 255, 255));
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblNewLabel.setBounds(26, 143, 115, 48);
		panel_1.add(lblNewLabel);
		
		JLabel lblNewLabel_2_2 = new JLabel("ID :");
		lblNewLabel_2_2.setForeground(Color.WHITE);
		lblNewLabel_2_2.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_2_2.setBounds(10, 190, 62, 26);
		panel_1.add(lblNewLabel_2_2);
		Statement statement = dbConn.getStatement();
		
		String selectQuery = "SELECT s_ID FROM `studentdata`";
		try {
			ResultSet resultSet = statement.executeQuery(selectQuery);
			while(resultSet.next()) {
				String idFromDB = resultSet.getString("s_ID");
				//ID = idFromDB;
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		JLabel lblNewLabel_2 = new JLabel("Name :");
		lblNewLabel_2.setForeground(new Color(255, 255, 255));
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_2.setBounds(10, 226, 62, 26);
		panel_1.add(lblNewLabel_2);
		
		JLabel lblNewLabel_2_1 = new JLabel("Sem :");
		lblNewLabel_2_1.setForeground(new Color(255, 255, 255));
		lblNewLabel_2_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_2_1.setBounds(10, 262, 45, 28);
		panel_1.add(lblNewLabel_2_1);
		
		JLabel lblNewLabel_2_1_1 = new JLabel("Level :");
		lblNewLabel_2_1_1.setForeground(new Color(255, 255, 255));
		lblNewLabel_2_1_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_2_1_1.setBounds(10, 300, 45, 26);
		panel_1.add(lblNewLabel_2_1_1);
		
		JLabel lblNewLabel_4 = new JLabel("");
		lblNewLabel_4.setIcon(new ImageIcon(studentFrontend.class.getResource("/Image/student.png")));
		lblNewLabel_4.setBounds(26, 10, 115, 123);
		panel_1.add(lblNewLabel_4);
		
		JButton btnNewButton_1_2_1_1 = new JButton("Logout");
		btnNewButton_1_2_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmStudent.dispose();
				new frontendApp();
			}
		});
		btnNewButton_1_2_1_1.setBounds(60, 352, 93, 26);
		panel_1.add(btnNewButton_1_2_1_1);
		
		idfield = new JTextField();
		idfield.setFont(new Font("Tahoma", Font.BOLD, 12));
		idfield.setBounds(60, 196, 119, 19);
		panel_1.add(idfield);
		idfield.setColumns(10);
		idfield.setText(userID);
		
		namefield = new JTextField();
		namefield.setFont(new Font("Tahoma", Font.BOLD, 12));
		namefield.setBounds(60, 232, 119, 19);
		panel_1.add(namefield);
		namefield.setColumns(10);
		
		namefield.setText(Name);
		
		
		semfield = new JTextField();
		semfield.setFont(new Font("Tahoma", Font.BOLD, 12));
		semfield.setBounds(60, 269, 119, 19);
		panel_1.add(semfield);
		semfield.setColumns(10);
		semfield.setText(sem);
		
		
		levelfield = new JTextField();
		levelfield.setFont(new Font("Tahoma", Font.BOLD, 12));
		levelfield.setBounds(60, 306, 119, 19);
		panel_1.add(levelfield);
		levelfield.setColumns(10);
		levelfield.setText(level);
		
		
		JPanel panel_2 = new JPanel();
		panel_2.setBackground(new Color(0, 0, 0));
		panel_2.setBounds(189, 10, 507, 49);
		panel.add(panel_2);
		panel_2.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("Welcome Student");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblNewLabel_1.setBounds(10, 10, 594, 21);
		panel_2.add(lblNewLabel_1);
		lblNewLabel_1.setBackground(new Color(0, 0, 0));
		lblNewLabel_1.setForeground(new Color(255, 255, 255));
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		
		JPanel panel_3 = new JPanel();
		panel_3.setLayout(null);
		panel_3.setBackground(Color.GRAY);
		panel_3.setBounds(199, 184, 485, 228);
		panel.add(panel_3); 
		
		JLabel lblNewLabel_5 = new JLabel("Course Details");
		
		lblNewLabel_5.setForeground(Color.WHITE);
		lblNewLabel_5.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_5.setBackground(Color.WHITE);
		lblNewLabel_5.setBounds(10, 10, 264, 31);
		panel_3.add(lblNewLabel_5);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(10, 61, 465, 84);
		panel_3.add(scrollPane_1);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane_1.setViewportView(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		table.setModel(moduleDefaultTableModel);
		
		JButton btnNewButton_2 = new JButton("View Report");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				reportGenerate reportGenerate = new reportGenerate(mobileNumber);
			}
		});
		btnNewButton_2.setBounds(337, 165, 138, 39);
		panel_3.add(btnNewButton_2);
		btnNewButton_2.setFont(new Font("Tahoma", Font.BOLD, 12));
		
		JPanel panel_2_1_1 = new JPanel();
		panel_2_1_1.setLayout(null);
		panel_2_1_1.setForeground(Color.LIGHT_GRAY);
		panel_2_1_1.setBackground(Color.LIGHT_GRAY);
		panel_2_1_1.setBounds(375, 69, 320, 105);
		panel.add(panel_2_1_1);
		
		JScrollPane scrollPane_3 = new JScrollPane();
		scrollPane_3.setBounds(10, 10, 300, 96);
		panel_2_1_1.add(scrollPane_3);
		
		JScrollPane scrollPane_2 = new JScrollPane();
		scrollPane_3.setViewportView(scrollPane_2);
		
		table_1 = new JTable();
		scrollPane_2.setViewportView(table_1);
		table_1.setModel(teacherModuleDefaultTableModelnew);
		table_1.getColumnModel().getColumn(1).setPreferredWidth(135);
		
		JPanel panel_2_1_2 = new JPanel();
		panel_2_1_2.setLayout(null);
		panel_2_1_2.setForeground(Color.LIGHT_GRAY);
		panel_2_1_2.setBackground(Color.LIGHT_GRAY);
		panel_2_1_2.setBounds(199, 69, 166, 105);
		panel.add(panel_2_1_2);
		
		JLabel lblNewLabel_3_2 = new JLabel("Assignment");
		lblNewLabel_3_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_3_2.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_3_2.setBounds(10, 0, 136, 25);
		panel_2_1_2.add(lblNewLabel_3_2);
		
		JButton btnNewButton_1_2_2 = new JButton("View");
		btnNewButton_1_2_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				new submitAssignmentStudent(Name,level,userID);
				
			}
		});
		btnNewButton_1_2_2.setBounds(35, 45, 89, 25);
		panel_2_1_2.add(btnNewButton_1_2_2);
		
		studentFrontend.showModuleDataInJtableFromDb();
		
	}
	

//	public Window getfrmAdmin() {
//		// TODO Auto-generated method stub
//		return null;
//	}
}
