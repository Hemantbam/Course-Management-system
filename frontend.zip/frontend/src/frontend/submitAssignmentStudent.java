package frontend;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import javax.swing.JTextPane;
import javax.swing.JComboBox;
import javax.swing.border.BevelBorder;
import javax.swing.border.SoftBevelBorder;
import java.awt.event.ItemListener;
import java.awt.event.ItemEvent;
import java.awt.event.InputMethodListener;
import java.awt.event.InputMethodEvent;

public class submitAssignmentStudent extends JDialog {
	private JComboBox ModuleComboBox;
	private final JPanel studentName = new JPanel();
	private String selectedModuleFromComboxBox = "NMC";
	private String courseName="";
	public String mname="";
	public String assignmentID ;
	public String questionFromDb="";

	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			
			submitAssignmentStudent dialog = new submitAssignmentStudent(null,null,null);
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	JLabel questionTextField = new JLabel("");

		public  submitAssignmentStudent(String name, String module, String username) {
		setVisible(true);
		setBounds(100, 100, 729, 497);
		getContentPane().setLayout(new BorderLayout());
		studentName.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(studentName, BorderLayout.CENTER);
		studentName.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBorder(new BevelBorder(BevelBorder.LOWERED, new Color(255, 0, 0), null, null, null));
		panel.setBackground(new Color(64, 0, 128));
		panel.setBounds(174, 49, 541, 79);
		studentName.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel_3 = new JLabel("Modu0le ");
		lblNewLabel_3.setBackground(new Color(255, 255, 255));
		lblNewLabel_3.setBounds(10, 20, 74, 22);
		panel.add(lblNewLabel_3);
		lblNewLabel_3.setForeground(new Color(255, 255, 255));
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 18));
		
		JComboBox ModuleComboBox = new JComboBox();
		// Select each data on the combo box 
		ModuleComboBox.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == 1) {
					selectedModuleFromComboxBox = (String) e.getItem();
					
					
					Statement statement = dbConn.getStatement();
//					System.out.println(selectedModuleFromComboxBox);
					String queryForQuestion="SELECT a_ID,question FROM `assignment` WHERE moduleName='"+selectedModuleFromComboxBox+"'";
//					System.out.println(queryForQuestion);
					try {
						ResultSet resultSet = statement.executeQuery(queryForQuestion);
						while(resultSet.next()) {
							questionFromDb =resultSet.getString("question");
//							System.out.println(questionFromDb);
							questionTextField.setText(questionFromDb);
							assignmentID=resultSet.getString("a_ID");
						}

					} catch (SQLException e1) {
						e1.printStackTrace();
					}
				
				}
				
			}
		});
		ModuleComboBox.setForeground(new Color(255, 255, 255));
		ModuleComboBox.setBackground(new Color(0, 0, 0));
		ModuleComboBox.setBounds(94, 18, 376, 30);
		panel.add(ModuleComboBox);
		ModuleComboBox.setFont(new Font("Tahoma", Font.BOLD, 12));
		
		JTextPane answerText = new JTextPane();
		answerText.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		answerText.setBounds(260, 240, 419, 119);
		studentName.add(answerText);
		
		
		questionTextField.setBorder(new SoftBevelBorder(BevelBorder.LOWERED, null, null, null, null));
		questionTextField.setFont(new Font("Tahoma", Font.PLAIN, 12));
		questionTextField.setBounds(260, 137, 413, 79);
		studentName.add(questionTextField);
		
		
		
		
		
//		if(selectedModuleFromComboxBox== "NMC") {
		Statement statement = dbConn.getStatement();
//		System.out.println(selectedModuleFromComboxBox);
		String queryForQuestion="SELECT a_id,question FROM `assignment` WHERE moduleName='"+selectedModuleFromComboxBox+"'";
//		System.out.println(queryForQuestion);
		try {
			ResultSet resultSet = statement.executeQuery(queryForQuestion);
			while(resultSet.next()) {
				questionFromDb =resultSet.getString("question");
//				System.out.println(questionFromDb);
//				assignmentID=resultSet.getString("a_id");
			}

		} catch (SQLException e1) {
			e1.printStackTrace();
		}
			

		questionTextField.setText(questionFromDb);
		JPanel panel_1 = new JPanel();
		panel_1.setLayout(null);
		panel_1.setBackground(new Color(64, 0, 128));
		panel_1.setBounds(0, 0, 173, 460);
		studentName.add(panel_1);
		
		JLabel lblAssignment = new JLabel("Assignment");
		lblAssignment.setHorizontalAlignment(SwingConstants.CENTER);
		lblAssignment.setForeground(Color.WHITE);
		lblAssignment.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblAssignment.setBounds(10, 156, 153, 60);
		panel_1.add(lblAssignment);
		
		JLabel lblNewLabel_4 = new JLabel("");
		lblNewLabel_4.setBounds(30, 60, 115, 123);
		panel_1.add(lblNewLabel_4);
		
		Statement statement1 = dbConn.getStatement();
		String Selectquery = "SELECT m_Name FROM `moduledata` WHERE courseName ='BIT'";

		try {
			ResultSet resultSet = statement1.executeQuery(Selectquery);
			while(resultSet.next()) {
				ModuleComboBox.addItem(resultSet.getString("m_Name"));

			}

		} catch (SQLException e1) {
			e1.printStackTrace();
		}
//		System.out.println(ModuleComboBox.getSelectedIndex());
		
		JPanel panel_2 = new JPanel();
		panel_2.setLayout(null);
		panel_2.setBackground(Color.BLACK);
		panel_2.setBounds(174, 0, 541, 50);
		studentName.add(panel_2);
		
		JLabel lblNewLabel_1 = new JLabel("Submit Assignment");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setForeground(Color.WHITE);
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblNewLabel_1.setBackground(Color.BLACK);
		lblNewLabel_1.setBounds(10, 0, 521, 49);
		panel_2.add(lblNewLabel_1);
		
		JLabel lblNewLabel = new JLabel("Question");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel.setBounds(183, 158, 89, 38);
		studentName.add(lblNewLabel);
		
		JLabel lblAssignment_1 = new JLabel("Answer");
		lblAssignment_1.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblAssignment_1.setBounds(183, 277, 74, 38);
		studentName.add(lblAssignment_1);
		
		courseName = answerText.getText().trim();
		
		JButton btnNewButton = new JButton("Submit");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Statement statement2 = dbConn.getStatement();
				String InsertInDB ="INSERT INTO `submittedassignment` (`a_id`,`question`,`answer`, `studentUsername`, `studentName`, `moduleName`) "
						+ "VALUES ('"+assignmentID+"','"+questionFromDb +"', '"+answerText.getText().toString()+"', '"+username +"', '"+name +"', '"+ selectedModuleFromComboxBox+"')";
				
				try {
//					statement.executeQuery(InsertInDB);
					
					int insertSuccess = statement2.executeUpdate(InsertInDB);
					
					if(insertSuccess == 1) {
						JOptionPane.showMessageDialog(studentName, "Assignment Submitted");
						dispose();
					} 
					adminFrontend.showModule();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}					
				dispose();
			}
		});



		btnNewButton.setBounds(537, 385, 148, 48);
		studentName.add(btnNewButton);
		
		JLabel lblNewLabel_2 = new JLabel("Student Name:");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel_2.setBounds(183, 369, 136, 30);
		studentName.add(lblNewLabel_2);
		
		JLabel nameofstudent = new JLabel("");
		nameofstudent.setFont(new Font("Tahoma", Font.PLAIN, 12));
		nameofstudent.setBounds(307, 369, 148, 30);
		studentName.add(nameofstudent);
		nameofstudent.setText(name);
		
		JLabel lblNewLabel_2_1 = new JLabel("Username :");
		lblNewLabel_2_1.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel_2_1.setBounds(183, 403, 136, 30);
		studentName.add(lblNewLabel_2_1);
		
		JLabel studentUsername = new JLabel("");
		studentUsername.setFont(new Font("Tahoma", Font.PLAIN, 12));
		studentUsername.setBounds(307, 403, 148, 30);
		studentName.add(studentUsername);
		studentUsername.setText(username);
		
	
	}

}
