package frontend;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JScrollPane;
import javax.swing.border.MatteBorder;
import javax.swing.border.BevelBorder;

public class reportGenerate extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private static JTextField studentNameTextField;
	private static String studentMobilenumber ="";
	private String avg="";
	private String Name ="";
	private String sem = "";
	private int percentage;
	private JTable table;
	private JTextField percentagetextField;
	private JTextField reviewtextField_1;

	private static DefaultTableModel ShowMarksDefaultTableModel = new DefaultTableModel(
			new Object[][] {
				{null, null},
				{null, null},
				{null, null},
			},
			new String[] {
				"Module", "Marks"
			}
		);
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			reportGenerate dialog = new reportGenerate(null);
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	

	

	public static void showmarksDataInJtableFromDb() {
		System.out.println(studentMobilenumber);
		// Connection con; con = dbConn.getConnection();
		Statement statement = dbConn.getStatement();
		
		String selectQuery = "SELECT moduleName,marks FROM `submittedassignment` WHERE studentUsername='" + studentMobilenumber + "'";
		
		ResultSet resultSet;
		try {
			resultSet = statement.executeQuery(selectQuery);
			ShowMarksDefaultTableModel.setRowCount(0);
			while (resultSet.next()) {
				// varchar getString()
				// bigint getBigDecimal()
				// date getDate()
				
				String moduleNameFromDb = resultSet.getString("moduleName");
				int  marksFromDb = resultSet.getInt("marks");


				ShowMarksDefaultTableModel.addRow(new Object[] {moduleNameFromDb,marksFromDb});

				

			}
			

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	/**
	 * Create the dialog.
	 */
	public reportGenerate(String mobileNumber) {
		studentMobilenumber=mobileNumber;
		
		try {
		Statement statement = dbConn.getStatement();
		String selectQuery = "SELECT s_Name,Percentage FROM `studentReport` WHERE mobileNumber='"+ studentMobilenumber +"'";
		ResultSet resultSet;
		resultSet = statement.executeQuery(selectQuery);
		while (resultSet.next()) {
//			System.out.println(resultSet);
			avg=resultSet.getString("Percentage");
			percentage =resultSet.getInt("Percentage");
			Name=resultSet.getString("s_Name");
		}

	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
		setVisible(true);
		setTitle("Report");
		setBounds(100, 100, 452, 316);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(64, 0, 128));
		panel.setBounds(0, 0, 136, 279);
		contentPanel.add(panel);
		panel.setLayout(null);
		
		studentNameTextField = new JTextField();
		studentNameTextField.setEditable(false);
		studentNameTextField.setColumns(10);
		studentNameTextField.setBounds(10, 198, 120, 19);
		panel.add(studentNameTextField);
		studentNameTextField.setText(Name);
		
		JLabel lblNewLabel_2_1 = new JLabel("Student Name");
		lblNewLabel_2_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2_1.setForeground(Color.LIGHT_GRAY);
		lblNewLabel_2_1.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_2_1.setBounds(10, 169, 120, 19);
		panel.add(lblNewLabel_2_1);
		
		JLabel lblNewLabel_3 = new JLabel("");
		lblNewLabel_3.setIcon(new ImageIcon(reportGenerate.class.getResource("/Image/studentResult.png")));
		lblNewLabel_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_3.setBounds(10, 10, 120, 128);
		panel.add(lblNewLabel_3);
		
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(0, 0, 0));
		panel_1.setBounds(141, 0, 303, 35);
		contentPanel.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("View Report");
		lblNewLabel.setForeground(new Color(255, 255, 255));
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(10, 0, 283, 35);
		panel_1.add(lblNewLabel);
		
		

		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(146, 62, 269, 109);
		contentPanel.add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		table.setModel(ShowMarksDefaultTableModel);
		
		JLabel lblNewLabel_1 = new JLabel("Percentage      =");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 11));
		lblNewLabel_1.setBounds(146, 181, 94, 25);
		contentPanel.add(lblNewLabel_1);
		
		percentagetextField = new JTextField();
		percentagetextField.setBorder(new BevelBorder(BevelBorder.LOWERED, new Color(204, 255, 153), null, null, null));
		percentagetextField.setEditable(false);
		percentagetextField.setBounds(250, 181, 120, 25);
		contentPanel.add(percentagetextField);
		percentagetextField.setColumns(10);
		percentagetextField.setText(avg);
		
		String pass="";
		String fail="";
		
		
		
		reviewtextField_1 = new JTextField();
		reviewtextField_1.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		reviewtextField_1.setEditable(false);
		reviewtextField_1.setBounds(192, 231, 236, 25);
		contentPanel.add(reviewtextField_1);
		reviewtextField_1.setColumns(10);
		
		JLabel lblNewLabel_1_1 = new JLabel("Review");
		lblNewLabel_1_1.setFont(new Font("Tahoma", Font.PLAIN, 11));
		lblNewLabel_1_1.setBounds(146, 231, 38, 25);
		contentPanel.add(lblNewLabel_1_1);
		reportGenerate.showmarksDataInJtableFromDb();
	
	
		
		if(percentage >= 40) {
			pass=("Congrulation yo have Passed ");
			reviewtextField_1.setText(pass);
		}else {
			fail=("Failed !!");
			reviewtextField_1.setText(fail);
		}
		
		
	}
}
