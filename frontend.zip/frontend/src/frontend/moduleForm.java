package frontend;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.SpringLayout;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.ButtonGroup;
import javax.swing.ComboBoxModel;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JCheckBox;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import java.awt.Color;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.ImageIcon;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class moduleForm extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JTextField moduleNametextField;
	private JLabel lblNewLabel;
	private JLabel lblNewLabel_1;
	private JLabel lblNewLabel_2;
	private JLabel lblNewLabel_2_1;
	private JComboBox courseSelectedComboBox;
	private JComboBox levelSelectedComboBox;
	private JTextField creditValueTextField;
	private JLabel lblNewLabel_3;
	private JComboBox semesterSelectedComboBox;
	private JCheckBox isOptionalModuleCheckBox;
	private Statement statement;
	private final ButtonGroup buttonGroup = new ButtonGroup();
	private String btnNewButton;
	 String  ID="";
	private String m_Name = "";
	private String courseName="";
	private String level = "";
	private String sem = "";
	private String creditValue = "";
	private String optionalModule = "NO";
	private JPanel panel;
	private JLabel lblNewLabel_4;
	private JLabel lblNewLabel_5;
	private JLabel lblNewLabel_6;
	private JPanel panel_1;
	private JLabel lblNewLabel_7;


	public JComboBox getCourseSelectedComboBox() {
		return courseSelectedComboBox;
	}





	public ButtonGroup getButtonGroup() {
		return buttonGroup;
	}




	public JTextField getCreditValueTextField() {
		return creditValueTextField;
	}




	public JTextField getModuleNametextField() {
		return moduleNametextField;
	}




	public JComboBox getLevelSelectedComboBox() {
		return levelSelectedComboBox;
	}




	public JComboBox getSemesterSelectedComboBox() {
		return semesterSelectedComboBox;
	}




	public JCheckBox getIsOptionalModuleCheckBox() {
		return isOptionalModuleCheckBox;
	}




	/**
	 * Launch the application.
	 */
	
	
	public static void main(String[] args) {
		try {
			moduleForm dialog = new moduleForm("Add", 0);
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	
	
	
	public moduleForm(String action, int id) {
		setVisible(true);
		setTitle("Module Form");
		setBounds(100, 100, 571, 428);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		{
			lblNewLabel = new JLabel("Module Name\r\n");
			lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 15));
			lblNewLabel.setBounds(200, 66, 96, 13);
			contentPanel.add(lblNewLabel);
		}
		{
			moduleNametextField = new JTextField();
			moduleNametextField.setBounds(316, 61, 217, 23);
			contentPanel.add(moduleNametextField);
			moduleNametextField.setColumns(10);
		}
		{
			lblNewLabel_1 = new JLabel("Course Name");
			lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
			lblNewLabel_1.setBounds(200, 97, 100, 13);
			contentPanel.add(lblNewLabel_1);
		}
		{
			courseSelectedComboBox = new JComboBox();
			courseSelectedComboBox.setFont(new Font("Tahoma", Font.PLAIN, 15));
			courseSelectedComboBox.setBounds(316, 94, 152, 19);
			
			//Get course name from Course table
			statement = dbConn.getStatement();
			
			String selectQuery = "SELECT c_Name FROM `coursedata`";
			
//			String courseNames [] = new String[3];
//			int i = 0;
			try {
				ResultSet resultSet = statement.executeQuery(selectQuery);
				while(resultSet.next()) {
					courseSelectedComboBox.addItem(resultSet.getString("c_Name"));
//					String courseNameFromDB = resultSet.getString("c_Name");
//					courseNames[i] = courseNameFromDB;
//					i++;
				}
				
			} catch (SQLException e) {
				e.printStackTrace();
			}
//			courseSelectedComboBox.setModel(new DefaultComboBoxModel(new String[] {"Select Course",courseNames[0],courseNames[1]}));

			contentPanel.add(courseSelectedComboBox);
		}
		{
			lblNewLabel_2 = new JLabel("Level");
			lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 15));
			lblNewLabel_2.setBounds(200, 128, 67, 13);
			contentPanel.add(lblNewLabel_2);
		}
		{
			lblNewLabel_2_1 = new JLabel("Semester\r\n");
			lblNewLabel_2_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
			lblNewLabel_2_1.setBounds(200, 171, 96, 13);
			contentPanel.add(lblNewLabel_2_1);
		}
		{
			levelSelectedComboBox = new JComboBox();
			levelSelectedComboBox.setFont(new Font("Tahoma", Font.PLAIN, 15));
			levelSelectedComboBox.setBounds(316, 123, 156, 19);
			levelSelectedComboBox.setModel(new DefaultComboBoxModel(new String[] {"Select Level", "Level 4", "Level 5", "Level 6"}));
			contentPanel.add(levelSelectedComboBox);
		}
		{
			semesterSelectedComboBox = new JComboBox();
			semesterSelectedComboBox.setFont(new Font("Tahoma", Font.PLAIN, 15));
			semesterSelectedComboBox.setBounds(317, 170, 151, 19);
			semesterSelectedComboBox.setModel(new DefaultComboBoxModel(new String[] {"Select Semester", "1st Semester", "2nd Semester"}));
			contentPanel.add(semesterSelectedComboBox);
		}
		{
			lblNewLabel_3 = new JLabel("Credit Value\r\n");
			lblNewLabel_3.setFont(new Font("Tahoma", Font.PLAIN, 15));
			lblNewLabel_3.setBounds(200, 219, 87, 13);
			contentPanel.add(lblNewLabel_3);
		}
		{
			creditValueTextField = new JTextField();
			creditValueTextField.setBounds(316, 218, 96, 19);
			contentPanel.add(creditValueTextField);
			creditValueTextField.setColumns(10);
		}
		{
			isOptionalModuleCheckBox = new JCheckBox("Optional Module");
			isOptionalModuleCheckBox.setFont(new Font("Tahoma", Font.PLAIN, 15));
			isOptionalModuleCheckBox.setBounds(316, 253, 152, 21);
			contentPanel.add(isOptionalModuleCheckBox);
		}
		{
			panel = new JPanel();
			panel.setLayout(null);
			panel.setBackground(new Color(64, 0, 128));
			panel.setBounds(0, 0, 170, 395);
			contentPanel.add(panel);
			{
				lblNewLabel_4 = new JLabel("Module Detail");
				lblNewLabel_4.setHorizontalAlignment(SwingConstants.CENTER);
				lblNewLabel_4.setForeground(Color.WHITE);
				lblNewLabel_4.setFont(new Font("Tahoma", Font.BOLD, 17));
				lblNewLabel_4.setBounds(10, 207, 150, 47);
				panel.add(lblNewLabel_4);
			}
			{
				lblNewLabel_5 = new JLabel("CMS");
				lblNewLabel_5.setHorizontalAlignment(SwingConstants.CENTER);
				lblNewLabel_5.setForeground(Color.WHITE);
				lblNewLabel_5.setFont(new Font("Tahoma", Font.BOLD, 30));
				lblNewLabel_5.setBounds(10, 10, 150, 78);
				panel.add(lblNewLabel_5);
			}
			{
				lblNewLabel_6 = new JLabel("");
				lblNewLabel_6.setIcon(new ImageIcon(moduleForm.class.getResource("/Image/icon form.png")));
				lblNewLabel_6.setHorizontalAlignment(SwingConstants.CENTER);
				lblNewLabel_6.setBounds(10, 78, 150, 130);
				panel.add(lblNewLabel_6);
			}
		}
		{
			panel_1 = new JPanel();
			panel_1.setBackground(Color.BLACK);
			panel_1.setBounds(174, 0, 369, 41);
			contentPanel.add(panel_1);
			{
				lblNewLabel_7 = new JLabel("Add Module");
				lblNewLabel_7.setForeground(Color.WHITE);
				lblNewLabel_7.setFont(new Font("Tahoma", Font.BOLD, 25));
				panel_1.add(lblNewLabel_7);
			}
		}
		
		JButton btnNewButton = new JButton(action);
		btnNewButton.setActionCommand(action);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String moduleName = moduleNametextField.getText().trim();
				String selectedCourseName = courseSelectedComboBox.getSelectedItem().toString();
				String selectedLevel = levelSelectedComboBox.getSelectedItem().toString();
				String creditValue = creditValueTextField.getText().trim();
				String selectedSemester = semesterSelectedComboBox.getSelectedItem().toString();
				String isOptionalModule = "";
				if(isOptionalModuleCheckBox.isSelected()) {
					isOptionalModule ="YES";
				}else {
					isOptionalModule ="NO";
				}
				
				if(action == "Add") {
					if (e.getActionCommand().equals(action)) {
						Statement statement2 = dbConn.getStatement();
						String selectIDfromDB ="SELECT ID FROM `coursedata` WHERE c_Name='" + selectedCourseName + "'";
						try {
							ResultSet resultSet = statement.executeQuery(selectIDfromDB);
							resultSet.next();
							int ID = resultSet.getInt("ID");
							
							String insertQuery = "INSERT INTO `moduledata` (`c_ID`,`m_Name`, `courseName`, `Level`, `Sem`, `creditValue`, `optionalModule`) "
									+ "VALUES ('"+ID +"','"+moduleName +"', '"+selectedCourseName +"', '"+selectedLevel +"', '"+selectedSemester +"', '"+ creditValue+"', '"+isOptionalModule +"')";
							int insertSuccess = statement2.executeUpdate(insertQuery);
							if(insertSuccess == 1) {
								JOptionPane.showMessageDialog(contentPanel, "Saved into database!");
								dispose();
							}
							adminFrontend.showModule();
						} catch (SQLException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}					
					}
				}
				else if(action == "Update") {
						String updateDB = "UPDATE `moduledata` SET `m_Name`='"+moduleName+"',`courseName`='"+selectedCourseName+"',`level`='"+selectedLevel+"',`sem`='"+selectedSemester +"',`creditValue`='"+ creditValue+"',`optionalModule`='"+isOptionalModule +"' WHERE `ID`='"+id+"'";
						Statement statement2 = dbConn.getStatement();
					try {
						int updateSuccess = statement2.executeUpdate(updateDB);
						if(updateSuccess == 1) {
							JOptionPane.showMessageDialog(contentPanel, "Updated into database!");
							dispose();
						}
						adminFrontend.showModule();
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}	
				}
				dispose();
			}
			
		});
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnNewButton.setBackground(new Color(0, 255, 0));
		btnNewButton.setBounds(316, 319, 108, 41);
		contentPanel.add(btnNewButton);

	}
}