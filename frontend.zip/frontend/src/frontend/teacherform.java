package frontend;
import java.awt.EventQueue;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import javax.swing.JRadioButton;
import javax.swing.SpringLayout;
import javax.swing.JCheckBox;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Enumeration;
import java.awt.event.ActionEvent;

import javax.swing.AbstractButton;
import javax.swing.ButtonGroup;
import javax.swing.ComboBoxModel;
import javax.swing.JList;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import java.awt.event.ItemListener;
import java.math.BigDecimal;
import java.awt.event.ItemEvent;
import javax.swing.ImageIcon;
import javax.swing.SwingConstants;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JSeparator;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.border.MatteBorder;

public class teacherform extends JFrame {
	private JPanel formPanel;
	private JTextField addressTextField;
	private JLabel lblNewLabel_3;
	private JTextField fullNametextField;
	private JLabel lblNewLabel_7;
	private JLabel lblNewLabel_6;
	private JButton submitButton;
	private final ButtonGroup buttonGroup = new ButtonGroup();
	private JCheckBox isPartTimeCheckBox;
	private JComboBox assignedModulecomboBox;
	private String name = "";
	private String mobileNo="";
	private String address = "";
	private String gender = "";
	private String isPartTime = "NO";
	private String selectedModuleFromComboxBox = "";
	private JPanel panel;
	private JLabel lblNewLabel_4;
	private JLabel lblNewLabel_5;
	private static DefaultTableModel teacherDefaultTableModel = new DefaultTableModel(
				new Object[][] {
					{null, null, null, null, null, null, null},
					{null, null, null, null, null, null, null},
					{null, null, null, null, null, null, null},
					{null, null, null, null, null, null, null},
					{null, null, null, null, null, null, null},
					{null, null, null, null, null, null, null},
				},
				new String[] {
					"ID", "Name", "Gender","mobileNo", "Address", "ModuleAssigned", "isPartTime"
				}
			);
	  private JTable teacherTable;
	  private JScrollPane scrollPane;
	  private JScrollPane scrollPane_1;
	  private JLabel lblNewLabel_9;
	  private JTextField mobileNumber;
	  private JTextField usernameTeacher;
	
	public JButton getSubmitButton() {
		return submitButton;
	}
	
	public ButtonGroup getButtonGroup() {
		return buttonGroup;
	}

	public JTextField getAddressTextField() {
		return addressTextField;
	}

	public JTextField getFullNametextField() {
		return fullNametextField;
	}
	

	public JTextField getMobileNumber() {
		return mobileNumber;
	}

	public JCheckBox getIsPartTimeCheckBox() {
		return isPartTimeCheckBox;
	}

	public JComboBox getAssignedModulecomboBox() {
		return assignedModulecomboBox;
	}

	public String getAddress() {
		return address;
	}

	public String getGender() {
		return gender;
	}

	public String getIsPartTime() {
		return isPartTime;
	}

	/**
	 * Create the dialog.
	 */
	public teacherform(){
		initialize();
		
	}
	 public static void showTeacherDataInJtableFromDb(){
		
			  Statement statement = dbConn.getStatement();

				String selectQuery = "SELECT * FROM `techer`";

				ResultSet resultSet;
				try {
					resultSet = statement.executeQuery(selectQuery);
					teacherDefaultTableModel.setRowCount(0);
					while (resultSet.next()) {
						int idFromDb = resultSet.getInt("Id");
						// varchar getString()
						// bigint getBigDecimal()
						// date getDate()
						String nameFromDb = resultSet.getString("Name");
						String genderFromDb = resultSet.getString("Gender");
						String mobileNumberFromDb = resultSet.getString("mobileNumber");
						String addressFromDb = resultSet.getString("Address");
						String moduleAssignedFromDb = resultSet.getString("Module_Assigned");
						String isPartTimeFromDb = resultSet.getString("is_PartTime");

						teacherDefaultTableModel.addRow(new Object[] { idFromDb, nameFromDb, genderFromDb, mobileNumberFromDb,
								addressFromDb, moduleAssignedFromDb, isPartTimeFromDb });


					}

				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}
	
	@SuppressWarnings("unchecked")
	private void initialize() {
		setTitle("Add Teacher Form");
		setBounds(100, 100, 617, 680);
		formPanel = new JPanel();
		setContentPane(formPanel);
		setVisible(true);
		

		JLabel lblNewLabel = new JLabel("FullName\r\n");
		lblNewLabel.setBounds(233, 72, 61, 13);
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 12));

		fullNametextField = new JTextField();
		fullNametextField.setBounds(304, 65, 269, 29);
		fullNametextField.setColumns(10);

		submitButton = new JButton("Submit");
		submitButton.setBackground(new Color(0, 255, 0));
		submitButton.setBounds(347, 291, 121, 34);
		submitButton.setFont(new Font("Tahoma", Font.BOLD, 14));
		submitButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				if (fullNametextField.getText().isEmpty()) {
					lblNewLabel_6.setVisible(true);
				} else {
					lblNewLabel_6.setVisible(false);
				}

				String name = fullNametextField.getText().trim(); // Ram
				String address = addressTextField.getText().trim();
				String mobileNo = mobileNumber.getText().trim();

				for (Enumeration<AbstractButton> buttons = buttonGroup.getElements(); buttons.hasMoreElements();) {
					AbstractButton button = buttons.nextElement();

					if (button.isSelected()) {
						gender = button.getText(); // female
					}
				}

				if (isPartTimeCheckBox.isSelected()) {
					isPartTime = "YES";
				} else {
					isPartTime = "NO";

				}
				String moduleName = assignedModulecomboBox.getModel().getSelectedItem().toString();
				
				Statement statement = dbConn.getStatement();

//				'"+   +"'
				String insertQuery = "INSERT INTO `techer` (`Name`, `Gender`,`Address`,`mobileNumber`, `Module_Assigned`, `is_PartTime`, `username`,`password`)"
						+ " VALUES ('" + name + "', '" + gender +"', '" + address + "','"+ mobileNo + "', '" + moduleName + "', '" + isPartTime + "','"+ mobileNo + "','"+ mobileNo + "')";

				try {
					int insertSuccess = statement.executeUpdate(insertQuery);

					if (insertSuccess == 1) {
						JOptionPane.showMessageDialog(formPanel, "Saved into Database");
					}
					teacherform.showTeacherDataInJtableFromDb();
					adminFrontend.showTeacherDataInJtableFromDb();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

				try {
					String selectQueryFromTeacher = "SELECT Name,Address FROM `techer` WHERE mobileNumber ='" + mobileNo+ "'";
					ResultSet resultSet = statement.executeQuery(selectQueryFromTeacher);
					resultSet.next();
					String Name = resultSet.getString("Name");
					String addressfromDB = resultSet.getString("Address");
					String user="Instructor";
					// Insert query into Student table
					String insertQueryForteacher = "INSERT INTO `useraccount` (`Name`, `Address`, `mobileNumber`, `userType`, `password`) "
							+ "VALUES ('"+ Name +"', '" + addressfromDB
							+ "','" + mobileNo+"','"+ user +"','"+ mobileNo +"')";
					statement.executeUpdate(insertQueryForteacher);
				} catch (Exception e2) {
					// TODO: handle exception
				}
				
				
				
				teacherform.showTeacherDataInJtableFromDb();

			


			}
		});

		addressTextField = new JTextField();
		addressTextField.setBounds(304, 149, 269, 29);
		addressTextField.setColumns(10);

		lblNewLabel_3 = new JLabel("Address\r\n");
		lblNewLabel_3.setBounds(233, 156, 61, 13);
		lblNewLabel_3.setFont(new Font("Tahoma", Font.PLAIN, 12));

		JRadioButton rdbtnNewRadioButton = new JRadioButton("Male");
		rdbtnNewRadioButton.setBounds(320, 115, 73, 21);
		rdbtnNewRadioButton.setFont(new Font("Tahoma", Font.PLAIN, 12));
		buttonGroup.add(rdbtnNewRadioButton);

		JRadioButton rdbtnNewRadioButton_1 = new JRadioButton("Female");
		rdbtnNewRadioButton_1.setBounds(406, 115, 78, 21);
		rdbtnNewRadioButton_1.setFont(new Font("Tahoma", Font.PLAIN, 12));
		buttonGroup.add(rdbtnNewRadioButton_1);

		lblNewLabel_7 = new JLabel("Sex");
		lblNewLabel_7.setBounds(233, 118, 26, 13);
		lblNewLabel_7.setFont(new Font("Tahoma", Font.PLAIN, 12));

		isPartTimeCheckBox = new JCheckBox("PartTime");
		isPartTimeCheckBox.setBounds(347, 179, 98, 23);
		isPartTimeCheckBox.setFont(new Font("Tahoma", Font.PLAIN, 12));

		lblNewLabel_6 = new JLabel("Full Name cannnot be empty!");
		lblNewLabel_6.setBounds(334, 93, 190, 16);
		lblNewLabel_6.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel_6.setForeground(new Color(255, 128, 128));
		lblNewLabel_6.setVisible(false);

		assignedModulecomboBox = new JComboBox();
		assignedModulecomboBox.setBounds(346, 240, 227, 19);
		assignedModulecomboBox.setFont(new Font("Tahoma", Font.PLAIN, 12));
				Statement statement = dbConn.getStatement();
				String selectQuery = "SELECT m_Name FROM `moduledata`";
				try {
					ResultSet resultSet = statement.executeQuery(selectQuery);
					while(resultSet.next()) {
						assignedModulecomboBox.addItem(resultSet.getString("m_Name"));

					}
					
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
				
	//	assignedModulecomboBox.setModel(new DefaultComboBoxModel(new String[] { "Select Module", "OODP", "NMC", "AI" }));

		JLabel lblNewLabel_2 = new JLabel("Assign Module\r\n");
		lblNewLabel_2.setBounds(233, 241, 105, 16);
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 12));
		
		panel = new JPanel();
		panel.setBounds(0, 0, 202, 648);
		panel.setBackground(new Color(64, 0, 128));
		panel.setLayout(null);
		
		JLabel lblNewLabel_8 = new JLabel("Teacher Detail");
		lblNewLabel_8.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_8.setForeground(new Color(255, 255, 255));
		lblNewLabel_8.setFont(new Font("Tahoma", Font.BOLD, 17));
		lblNewLabel_8.setBounds(0, 207, 202, 47);
		panel.add(lblNewLabel_8);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBounds(208, 0, 390, 41);
		panel_1.setBackground(Color.BLACK);
		
		JLabel lblNewLabel_1 = new JLabel("Add Teacher");
		lblNewLabel_1.setForeground(Color.WHITE);
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 25));
		panel_1.add(lblNewLabel_1);
		formPanel.setLayout(null);
		
		lblNewLabel_4 = new JLabel("CMS");
		lblNewLabel_4.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4.setForeground(Color.WHITE);
		lblNewLabel_4.setFont(new Font("Tahoma", Font.BOLD, 30));
		lblNewLabel_4.setBounds(10, 10, 182, 78);
		panel.add(lblNewLabel_4);
		
		lblNewLabel_5 = new JLabel("");
		lblNewLabel_5.setIcon(new ImageIcon(teacherform.class.getResource("/Image/icon form.png")));
		lblNewLabel_5.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_5.setBounds(10, 78, 182, 130);
		panel.add(lblNewLabel_5);
		
		formPanel.add(panel);
		formPanel.add(panel_1);
		formPanel.add(lblNewLabel);
		formPanel.add(lblNewLabel_6);
		formPanel.add(fullNametextField);
		formPanel.add(lblNewLabel_7);
		formPanel.add(rdbtnNewRadioButton);
		formPanel.add(rdbtnNewRadioButton_1);
		formPanel.add(lblNewLabel_3);
		formPanel.add(addressTextField);
		formPanel.add(isPartTimeCheckBox);
		formPanel.add(lblNewLabel_2);
		formPanel.add(assignedModulecomboBox);
		formPanel.add(submitButton);
		
		scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(212, 386, 381, 124);
		formPanel.add(scrollPane_1);
		
		scrollPane = new JScrollPane();
		scrollPane_1.setViewportView(scrollPane);
		
		teacherTable = new JTable();
		teacherTable.setDefaultEditor(Object.class, null);
		scrollPane.setViewportView(teacherTable);
		teacherTable.setModel(teacherDefaultTableModel);
		teacherTable.setDefaultEditor(Object.class, null);
		
		JPanel panel_1_1 = new JPanel();
		panel_1_1.setBackground(Color.BLACK);
		panel_1_1.setBounds(208, 335, 390, 41);
		formPanel.add(panel_1_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("Teacher Details");
		lblNewLabel_1_1.setForeground(Color.WHITE);
		lblNewLabel_1_1.setFont(new Font("Tahoma", Font.BOLD, 25));
		panel_1_1.add(lblNewLabel_1_1);
		
		lblNewLabel_9 = new JLabel("Mobile no");
		lblNewLabel_9.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel_9.setBounds(233, 218, 61, 13);
		formPanel.add(lblNewLabel_9);
		
		mobileNumber = new JTextField();
		mobileNumber.setBounds(347, 216, 137, 19);
		formPanel.add(mobileNumber);
		mobileNumber.setColumns(10);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBounds(208, 571, 390, 66);
		formPanel.add(panel_2);
		panel_2.setLayout(null);
		
		JLabel lblNewLabel_10 = new JLabel("Username :");
		lblNewLabel_10.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_10.setBounds(10, 10, 87, 19);
		panel_2.add(lblNewLabel_10);
		
		usernameTeacher = new JTextField();
		usernameTeacher.setFont(new Font("Tahoma", Font.PLAIN, 12));
		usernameTeacher.setBounds(95, 12, 164, 27);
		panel_2.add(usernameTeacher);
		usernameTeacher.setColumns(10);
		
		JButton btnNewButton = new JButton("Remove");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
					String mobileNumber = usernameTeacher.getText();
					if (mobileNumber.length() > 0) {

						Statement statement = dbConn.getStatement();
						String SelectTeacherQuery = "SELECT ID FROM `techer` WHERE mobileNumber='" + mobileNumber + "'";
						String deleteTeacherQuery = "DELETE FROM `techer` WHERE mobileNumber='" + mobileNumber + "'";
						String deleteTeacherUseraccountQuery = "DELETE FROM `useraccount` WHERE mobileNumber='" + mobileNumber + "'";
						try {
							int removeSuccess = statement.executeUpdate(deleteTeacherQuery);
							int removeUseraccount=	statement.executeUpdate(deleteTeacherUseraccountQuery);
							if(removeSuccess == 1 && removeUseraccount==1) {
								JOptionPane.showMessageDialog(formPanel, "Teacher Removed From Database");
							}
							teacherform.showTeacherDataInJtableFromDb();
							}
						 catch (Exception e1) {
							// TODO: handle exception
							e1.printStackTrace();
						}

					}

			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnNewButton.setForeground(new Color(255, 0, 0));
		btnNewButton.setBounds(269, 6, 104, 37);
		panel_2.add(btnNewButton);
		
		JLabel lblNewLabel_11 = new JLabel("Mobile Number is Username");
		lblNewLabel_11.setForeground(new Color(255, 123, 123));
		lblNewLabel_11.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_11.setBounds(95, 41, 164, 13);
		panel_2.add(lblNewLabel_11);
		
		JPanel panel_1_1_1 = new JPanel();
		panel_1_1_1.setBackground(Color.BLACK);
		panel_1_1_1.setBounds(205, 520, 393, 41);
		formPanel.add(panel_1_1_1);
		
		JLabel lblNewLabel_1_1_1 = new JLabel("Remove Teacher");
		lblNewLabel_1_1_1.setForeground(Color.WHITE);
		lblNewLabel_1_1_1.setFont(new Font("Tahoma", Font.BOLD, 25));
		panel_1_1_1.add(lblNewLabel_1_1_1);
		
		teacherform.showTeacherDataInJtableFromDb();
	}
	
	public static void main(String[] args) {
		new teacherform();
	}
}