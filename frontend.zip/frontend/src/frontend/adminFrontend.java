package frontend;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JMenuBar;
import javax.swing.JOptionPane;
import javax.swing.JSplitPane;
import javax.swing.JButton;
import java.awt.BorderLayout;
import javax.swing.JPanel;
import javax.swing.DefaultComboBoxModel;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import java.awt.Color;
import java.awt.Font;
import java.awt.CardLayout;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.SwingConstants;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import com.mysql.cj.jdbc.PreparedStatement;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.border.CompoundBorder;
import javax.swing.border.BevelBorder;
import javax.swing.border.SoftBevelBorder;
import javax.swing.border.MatteBorder;

public class adminFrontend {

	private JFrame frmAdmin;
	private JTable table;

	private static DefaultTableModel teacherDefaultTableModel = new DefaultTableModel(
			new Object[][] { { null, null, null, null, null, null }, { null, null, null, null, null, null },
					{ null, null, null, null, null, null }, { null, null, null, null, null, null },
					{ null, null, null, null, null, null }, },
			new String[] { "Name", "ID", "Gender", "Address", "Module_Assigned", "is_PartTime" });

	private static DefaultTableModel searchStudentDefaultTableModel = new DefaultTableModel(
			new Object[][] { { null, null, null, null, null, null,null }, { null, null, null, null, null, null,null }, },
			new String[] { "ID", "Name", "c_Enrolled", "Semester","Mobile Number", "Level", "cohort" });
	
	
	private static DefaultTableModel ModuleDefaultTableModel = new DefaultTableModel(
			new Object[][] {
				{null, null, null, null, null, null, null,null},
				{null, null, null, null, null, null, null,null},
				{null, null, null, null, null, null, null,null},
				{null, null, null, null, null, null, null,null},
				{null, null, null, null, null, null, null,null},
			},
			new String[] {
				"Module ID","Course ID", "Module Name", "Course Name", "Credit Value", "Level", "Semester ", "Optional Module"
			}
		);
	
	private static DefaultTableModel courseDefaultTableModel =new DefaultTableModel(
			new Object[][] {
				{null, null, null, null, null, null,null},
				{null, null, null, null, null, null,null},
				{null, null, null, null, null, null,null},
				{null, null, null, null, null, null,null},
			},
			new String[] {
				"course ID", "Name", "Description", "no_OFModule", "Level","Length in yrs" ,"Active Status"
			}
		);
	private JTable table_1;
	private JTextField studentname;
	private JTextField totalCourse;
	private JTextField totalStudent;
	private JTextField totalInstructor;
	private JPanel panel_6;
	private CardLayout cl_panel = new CardLayout(0, 0);
	private JTable table_2;
	private JTable table_3;
	private JTextField moduleID;
	private JTextField courseid;
	
	

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					adminFrontend window = new adminFrontend();
					window.frmAdmin.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});

	}
	
	public JFrame getFrmAdmin() {
		return frmAdmin;
	}


	/**
	 * Create the application.
	 * 
	 * @throws SQLException
	 */
	public adminFrontend() {
		initialize();
	}

	public static void showTeacherDataInJtableFromDb() {

		// Connection con; con = dbConn.getConnection();
		Statement statement = dbConn.getStatement();

		String selectQuery = "SELECT * FROM `techer`";

		ResultSet resultSet;
		try {
			resultSet = statement.executeQuery(selectQuery);
			teacherDefaultTableModel.setRowCount(0);
			while (resultSet.next()) {
				int idFromDb = resultSet.getInt("Id");
				// varchar getString()
				// bigint getBigDecimal()
				// date getDate()
				String nameFromDb = resultSet.getString("Name");
				String addressFromDb = resultSet.getString("Address");
				String genderFromDb = resultSet.getString("Gender");
				String moduleAssignedFromDb = resultSet.getString("Module_Assigned");
				String isPartTimeFromDb = resultSet.getString("is_PartTime");

				teacherDefaultTableModel.addRow(new Object[] { idFromDb, nameFromDb, addressFromDb, genderFromDb,
						moduleAssignedFromDb, isPartTimeFromDb });

				

			}
			

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


	}
	
	public static void showModule() {
		Statement statement = dbConn.getStatement();

		String selectQuery = "SELECT * FROM `moduledata`";

		ResultSet resultSet;
		try {
			resultSet = statement.executeQuery(selectQuery);
			// resultSet = statement.executeQuery(searchStudentDetailQuery);
			ModuleDefaultTableModel.setRowCount(0);
			while (resultSet.next()) { // getting each row data from database
				int mIDFromDb=resultSet.getInt("ID");
				String nameFromDb = resultSet.getString("m_Name");
				int IDFromDb = resultSet.getInt("c_ID");
				String courseNameFromDb = resultSet.getString("courseName");
				String levelFromDb = resultSet.getString("level");
				String semFromDb = resultSet.getString("sem");
				int creditValue = resultSet.getInt("creditValue");
				String optionalModuleDbFromDb = resultSet.getString("optionalModule");
				ModuleDefaultTableModel.addRow(new Object[] { mIDFromDb, IDFromDb, nameFromDb,
						courseNameFromDb, creditValue, levelFromDb, semFromDb, optionalModuleDbFromDb });
			}
			
			
		} catch (Exception e1) {
			// TODO: handle exception
			e1.printStackTrace();
		}
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmAdmin = new JFrame();
		frmAdmin.setTitle("Admin");
		frmAdmin.setBounds(100, 100, 1061, 639);
		frmAdmin.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmAdmin.getContentPane().setLayout(null);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(196, 432, 562, -207);
		frmAdmin.getContentPane().add(scrollPane);

		JPanel panel = new JPanel();
		panel.setBackground(new Color(64, 0, 128));
		panel.setBounds(0, 10, 186, 611);
		frmAdmin.getContentPane().add(panel);
		panel.setLayout(null);

		JLabel lblNewLabel = new JLabel("Admin");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(10, 193, 166, 37);
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 30));
		lblNewLabel.setForeground(new Color(255, 255, 255));
		panel.add(lblNewLabel);

		JLabel lblNewLabel_2 = new JLabel("");
		lblNewLabel_2.setBounds(23, 30, 138, 142);
		lblNewLabel_2.setIcon(new ImageIcon(adminFrontend.class.getResource("/Image/admin2.png")));
		panel.add(lblNewLabel_2);
		
		JButton btnNewButton_5 = new JButton("Logout");
		btnNewButton_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmAdmin.dispose();
				new frontendApp();
			}
			
		});
		btnNewButton_5.setBounds(35, 485, 126, 44);
		panel.add(btnNewButton_5);
		
		JLabel lblDashboard = new JLabel("Dashboard");
		lblDashboard.setHorizontalAlignment(SwingConstants.CENTER);
		lblDashboard.setForeground(Color.WHITE);
		lblDashboard.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblDashboard.setBounds(10, 239, 166, 37);
		panel.add(lblDashboard);

		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(0, 0, 0));
		panel_1.setBounds(196, 10, 852, 41);
		frmAdmin.getContentPane().add(panel_1);

		JLabel lblNewLabel_1 = new JLabel("Welcome Admin");
		lblNewLabel_1.setForeground(new Color(255, 255, 255));
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 25));
		panel_1.add(lblNewLabel_1);

		JPanel panel_2 = new JPanel();
		panel_2.setBackground(new Color(192, 192, 192));
		panel_2.setForeground(new Color(192, 192, 192));
		panel_2.setBounds(201, 100, 284, 107);
		frmAdmin.getContentPane().add(panel_2);
		panel_2.setLayout(null);

		JLabel lblNewLabel_3 = new JLabel("Course");
		lblNewLabel_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_3.setBounds(10, 10, 264, 25);
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 20));
		panel_2.add(lblNewLabel_3);

		JButton addCourse = new JButton("Add Course");
		addCourse.setFont(new Font("Tahoma", Font.BOLD, 12));
		addCourse.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new course("Add", 0);
			}
		});
		addCourse.setBounds(10, 48, 264, 21);
		panel_2.add(addCourse);

		JButton btnNewButton_1 = new JButton("Update Course");
		btnNewButton_1.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnNewButton_1.setBounds(10, 79, 264, 21);
		panel_2.add(btnNewButton_1);

		JPanel panel_4 = new JPanel();
		panel_4.setBounds(196, 61, 852, 39);
		frmAdmin.getContentPane().add(panel_4);
		panel_4.setLayout(null);
		
		totalCourse = new JTextField();
		totalCourse.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		totalCourse.setEditable(false);
		totalCourse.setHorizontalAlignment(SwingConstants.CENTER);
		totalCourse.setFont(new Font("Tahoma", Font.PLAIN, 20));
		totalCourse.setBounds(123, 3, 62, 32);
		panel_4.add(totalCourse);
		totalCourse.setColumns(10);
		
		
		totalStudent = new JTextField();
		totalStudent.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		totalStudent.setEditable(false);
		totalStudent.setHorizontalAlignment(SwingConstants.CENTER);
		totalStudent.setFont(new Font("Tahoma", Font.PLAIN, 20));
		totalStudent.setBounds(441, 3, 62, 32);
		panel_4.add(totalStudent);
		totalStudent.setColumns(10);
		
		totalInstructor = new JTextField();
		totalInstructor.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		totalInstructor.setEditable(false);
		totalInstructor.setHorizontalAlignment(SwingConstants.CENTER);
		totalInstructor.setFont(new Font("Tahoma", Font.PLAIN, 20));
		totalInstructor.setBounds(746, 3, 62, 32);
		panel_4.add(totalInstructor);
		totalInstructor.setColumns(10);

						Statement statement = dbConn.getStatement();
						String countCourseQuery = "SELECT COUNT(ID) FROM `coursedata`";

						ResultSet resultSet;
						try {
							resultSet = statement.executeQuery(countCourseQuery);
							// resultSet = statement.executeQuery(searchStudentDetailQuery);
							while (resultSet.next()) {
								int total=resultSet.getInt("COUNT(ID)");
								totalCourse.setText(String.valueOf(total));
							}
						} catch (Exception e1) {
							// TODO: handle exception
							e1.printStackTrace();
						}

				
				String countStudentQuery = "SELECT COUNT(s_ID) FROM `studentdata`";

				try {
					resultSet = statement.executeQuery(countStudentQuery);
					// resultSet = statement.executeQuery(searchStudentDetailQuery);
					while (resultSet.next()) {
						int total=resultSet.getInt("COUNT(s_ID)");
						totalStudent.setText(String.valueOf(total));
					}
				} catch (Exception e1) {
					// TODO: handle exception
					e1.printStackTrace();
				}

				String countTeacherQuery = "SELECT COUNT(ID) FROM `techer`";

				try {
					resultSet = statement.executeQuery(countTeacherQuery);
					// resultSet = statement.executeQuery(searchStudentDetailQuery);
					while (resultSet.next()) {
						int total=resultSet.getInt("COUNT(ID)");
						totalInstructor.setText(String.valueOf(total));
					}
				} catch (Exception e1) {
					// TODO: handle exception
					e1.printStackTrace();
				}
		
		JLabel lblNewLabel_8 = new JLabel("Total Course");
		lblNewLabel_8.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel_8.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_8.setBounds(10, 3, 103, 32);
		panel_4.add(lblNewLabel_8);
		
		JLabel lblNewLabel_8_1 = new JLabel("Total Student");
		lblNewLabel_8_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_8_1.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel_8_1.setBounds(307, 3, 124, 32);
		panel_4.add(lblNewLabel_8_1);
		
		JLabel lblNewLabel_8_1_1 = new JLabel("Total Instructor");
		lblNewLabel_8_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_8_1_1.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel_8_1_1.setBounds(612, 3, 124, 32);
		panel_4.add(lblNewLabel_8_1_1);

		JPanel panel_2_1 = new JPanel();
		panel_2_1.setBounds(776, 102, 261, 105);
		frmAdmin.getContentPane().add(panel_2_1);
		panel_2_1.setLayout(null);
		panel_2_1.setForeground(Color.LIGHT_GRAY);
		panel_2_1.setBackground(Color.LIGHT_GRAY);

		JLabel lblNewLabel_3_1 = new JLabel("Instructor");
		lblNewLabel_3_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_3_1.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_3_1.setBounds(10, 13, 254, 25);
		panel_2_1.add(lblNewLabel_3_1);

		JButton btnNewButton_1_1_1_1 = new JButton("Add / Remove ");
		btnNewButton_1_1_1_1.setBorder(new SoftBevelBorder(BevelBorder.LOWERED, null, null, null, null));
		btnNewButton_1_1_1_1.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnNewButton_1_1_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new teacherform();
				System.out.println("Instructor");
			}
		});
		btnNewButton_1_1_1_1.setBounds(72, 48, 133, 47);
		panel_2_1.add(btnNewButton_1_1_1_1);

		JPanel panel_2_1_1 = new JPanel();
		panel_2_1_1.setLayout(null);
		panel_2_1_1.setForeground(Color.LIGHT_GRAY);
		panel_2_1_1.setBackground(Color.LIGHT_GRAY);
		panel_2_1_1.setBounds(494, 102, 272, 105);
		frmAdmin.getContentPane().add(panel_2_1_1);

		JLabel lblNewLabel_3_1_1 = new JLabel("Modules");
		lblNewLabel_3_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_3_1_1.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_3_1_1.setBounds(10, 10, 254, 25);
		panel_2_1_1.add(lblNewLabel_3_1_1);

		JButton btnNewButton_1_2_1_1 = new JButton("Add Module");
		btnNewButton_1_2_1_1.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnNewButton_1_2_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new moduleForm("Add", 0);
			//	cl_panel.show(panel_6, "name_90567635080000");
			}
		});
		btnNewButton_1_2_1_1.setBounds(10, 45, 254, 21);
		panel_2_1_1.add(btnNewButton_1_2_1_1);

		JButton btnNewButton_1_3_1 = new JButton("Update Module");
		btnNewButton_1_3_1.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnNewButton_1_3_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cl_panel.show(panel_6, "name_90567657238500");            //showing the pannel when clicked
				adminFrontend.showModule();
				
				
			}
			
			
		});
		btnNewButton_1_3_1.setBounds(10, 74, 254, 21);
		panel_2_1_1.add(btnNewButton_1_3_1);

		JSeparator separator = new JSeparator();
		separator.setBackground(new Color(128, 128, 192));
		separator.setForeground(new Color(128, 128, 192));
		separator.setBounds(196, 217, 831, 2);
		frmAdmin.getContentPane().add(separator);

		JPanel panel_3 = new JPanel();
		panel_3.setBackground(new Color(0, 0, 0));
		panel_3.setBounds(196, 222, 841, 381);
		frmAdmin.getContentPane().add(panel_3);
		panel_3.setLayout(null);
	//	panel_9.show();
		
		panel_6 = new JPanel();
		panel_6.setBackground(new Color(0, 0, 0));
		panel_6.setBounds(400, 10, 431, 361);
		panel_3.add(panel_6);
		panel_6.setLayout(cl_panel);
		
		JPanel panel_7 = new JPanel();
		panel_7.setBorder(new BevelBorder(BevelBorder.RAISED, new Color(128, 0, 255), null, null, null));
		panel_7.setBackground(new Color(0, 0, 0));
		panel_6.add(panel_7, "name_90567635080000");
		
		JPanel panel_1_1_1 = new JPanel();
		panel_1_1_1.setBounds(10, 10, 411, 41);
		panel_1_1_1.setBackground(Color.BLACK);
		
		JLabel lblNewLabel_1_1_1 = new JLabel("Course Details ");
		lblNewLabel_1_1_1.setForeground(Color.WHITE);
		lblNewLabel_1_1_1.setFont(new Font("Tahoma", Font.BOLD, 25));
		panel_1_1_1.add(lblNewLabel_1_1_1);
		panel_7.setLayout(null);
		panel_7.add(panel_1_1_1);
		
		JScrollPane scrollPane_8 = new JScrollPane();
		scrollPane_8.setBorder(new BevelBorder(BevelBorder.LOWERED, new Color(0, 0, 0), null, null, null));
		scrollPane_8.setBounds(10, 71, 411, 134);
		panel_7.add(scrollPane_8);
		
		JScrollPane scrollPane_7 = new JScrollPane();
		scrollPane_8.setViewportView(scrollPane_7);
		
		table_3 = new JTable();
		table_3.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				System.out.println(table_3.getSelectedRow());
				Object[] options = { "Update", "Back" };  // created two object with two options
				int n = JOptionPane.showOptionDialog(null, "Do you want to update ",
						"Update ", JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null,
						options, options[0]);
				if (n == 0) { //if first option is selected then 
					int id = Integer.parseInt(table_3.getValueAt(table_3.getSelectedRow(), 0).toString());
					System.out.println(id);
					course course = new  course("Update", id);
					course.setVisible(true);
					course.setTitle("Update Course ");

					 String c_Name = "";
					 String desc="";
					 String noOfModule = "";
					 String level = "";
					 String lengthOfC = "";
					 String activeStatus = "NO";
					
					int selectedRowNo = table_3.getSelectedRow();  // this will provide us the index of selected row
					for (int columnIndex = 1; columnIndex < table_3.getColumnCount(); columnIndex++) { // thsi will give the data on each column of that row
						if (c_Name.isEmpty()) {
							c_Name = table_3.getValueAt(table_3.getSelectedRow(), columnIndex).toString();
						} else if (desc.isEmpty()) {
							desc = table_3.getValueAt(table_3.getSelectedRow(), columnIndex)
									.toString();
						} else if (noOfModule.isEmpty()) {
							noOfModule = table_3.getValueAt(table_3.getSelectedRow(), columnIndex).toString();
						} else if (level.isEmpty()) {
							level = table_3.getValueAt(table_3.getSelectedRow(), columnIndex).toString();
						} else if (lengthOfC.isEmpty()) {
							lengthOfC = table_3
									.getValueAt(table_3.getSelectedRow(), columnIndex).toString();
						} else if (activeStatus.isEmpty()) {
							activeStatus = table_3.getValueAt(table_3.getSelectedRow(), columnIndex)
									.toString();
						} 
					
					}
					// this will provide the data to course class text fields 
					course.getCourseNameTextField().setText(c_Name);
					course.getCourseDescriptionTextField().setText(desc);
					course.getLengthOfTheCourseTextField().setText(lengthOfC);
					course.getNoOfModulesTextField().setText(noOfModule);
					
				
				}
				
				
				
				
				
				
				
				
				
				
				
			}
		});
		scrollPane_7.setViewportView(table_3);
		table_3.setModel(courseDefaultTableModel);
		
		JLabel lblNewLabel_4_2 = new JLabel("Course ID :");
		lblNewLabel_4_2.setForeground(new Color(255, 255, 255));
		lblNewLabel_4_2.setBackground(new Color(0, 0, 0));
		lblNewLabel_4_2.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_4_2.setBounds(10, 215, 109, 29);
		panel_7.add(lblNewLabel_4_2);
		
		courseid = new JTextField();
		courseid.setColumns(10);
		courseid.setBounds(137, 215, 238, 29);
		panel_7.add(courseid);
		
		
		// delete the course data 
		JButton btnNewButton_4 = new JButton("Delete");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String courseIDtext = courseid.getText();
				if (courseIDtext.length() > 0) {
					 
					// below wueries will delete the course data from both course and modue table
					Statement statement = dbConn.getStatement();
					String deleteCourseQuery = "DELETE FROM `coursedata` WHERE ID='" + courseIDtext + "'";
					String deleteModuleQuery = "DELETE FROM `moduledata` WHERE c_ID='" + courseIDtext + "'";
					
					try {
						int deleteCourse = statement.executeUpdate(deleteCourseQuery);
						int deleteModule = statement.executeUpdate(deleteModuleQuery);
						if(deleteCourse ==1 || deleteModule==1) {
							JOptionPane.showMessageDialog(panel_7, "Course Data Deleted");
						}
						adminFrontend.showCourseTable();
						}
					 catch (Exception e1) {
						// TODO: handle exception
						e1.printStackTrace();
					}

				}
			}
		});
		btnNewButton_4.setForeground(Color.WHITE);
		btnNewButton_4.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnNewButton_4.setBackground(Color.RED);
		btnNewButton_4.setBounds(137, 254, 114, 31);
		panel_7.add(btnNewButton_4);
		
		JButton btnCancel = new JButton("Cancel");
		btnCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String courseIDtext = courseid.getText();
				if (courseIDtext.length() > 0) {
					
					// this will set the active status no when cancel button is clicked
					Statement statement = dbConn.getStatement();
					String cancelCourseQuery = "UPDATE coursedata SET active_Status = 'NO' WHERE ID='" + courseIDtext + "'";

					try {
						int cancelSuccess = statement.executeUpdate(cancelCourseQuery);
						if(cancelSuccess ==1) {
							JOptionPane.showMessageDialog(panel_7, "Course Deactivated");
						}
						adminFrontend.showCourseTable();
						}
					 catch (Exception e1) {
						// TODO: handle exception
						e1.printStackTrace();
					}

				}
			}
		});
		btnCancel.setForeground(Color.WHITE);
		btnCancel.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnCancel.setBackground(new Color(128, 64, 64));
		btnCancel.setBounds(261, 254, 114, 31);
		panel_7.add(btnCancel);
		
		JButton btnReactivate = new JButton("Reactivate");
		btnReactivate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String courseIDtext = courseid.getText();
				if (courseIDtext.length() > 0) {
					
					// when this button is clicked the course active status will be yes 
					Statement statement = dbConn.getStatement();
					String cancelCourseQuery = "UPDATE coursedata SET active_Status = 'YES' WHERE ID='" + courseIDtext + "'";

					try {
						int cancelSuccess = statement.executeUpdate(cancelCourseQuery);
						if(cancelSuccess ==1) {
							JOptionPane.showMessageDialog(panel_7, "Course Reactivated");
						}
						adminFrontend.showCourseTable();
						}
					 catch (Exception e1) {
						// TODO: handle exception
						e1.printStackTrace();
					}

				}
			}
		});
		btnReactivate.setForeground(Color.WHITE);
		btnReactivate.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnReactivate.setBackground(new Color(0, 128, 64));
		btnReactivate.setActionCommand("AddCourse");
		btnReactivate.setBounds(190, 295, 140, 35);
		panel_7.add(btnReactivate);
		
		JLabel lblNewLabel_4_3 = new JLabel("Click on respective Course row to update  text data");
		lblNewLabel_4_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4_3.setForeground(Color.RED);
		lblNewLabel_4_3.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel_4_3.setBounds(10, 47, 411, 24);
		panel_7.add(lblNewLabel_4_3);
		
		JPanel panel_8 = new JPanel();
		panel_8.setBorder(new BevelBorder(BevelBorder.RAISED, new Color(128, 0, 255), null, null, null));
		panel_8.setBackground(new Color(0, 0, 0));
		panel_6.add(panel_8, "name_90567657238500");
		panel_8.setLayout(null);
		
		JScrollPane scrollPane_5 = new JScrollPane();
		scrollPane_5.setBounds(10, 68, 411, 150);
		panel_8.add(scrollPane_5);
		
		JScrollPane scrollPane_4 = new JScrollPane();
		scrollPane_4.addMouseListener(new MouseAdapter() {
	});
		scrollPane_5.setViewportView(scrollPane_4);
		
		table_2 = new JTable();
		//table_2.
		table_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				System.out.println(table_2.getSelectedRow());
				Object[] options = { "Update", "Back" };
				int n = JOptionPane.showOptionDialog(null, "Do you want to update ",
						"Update ", JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null,
						options, options[0]);
				if (n == 0) {
					int id = Integer.parseInt(table_2.getValueAt(table_2.getSelectedRow(), 0).toString());
					System.out.println(id);
					moduleForm moduleForm = new  moduleForm("Update", id);
					moduleForm.setVisible(true);
					moduleForm.setTitle("Update Teacher Form");

					 String m_Name = "";
					 String courseName="";
//					 String level = "";
//					 String sem = "";
					 String creditValue = "";
//					 String optionalModule = "";
					
					int selectedRowNo = table_2.getSelectedRow();
					for (int columnIndex = 2; columnIndex < table_2.getColumnCount(); columnIndex++) {
						if (m_Name.isEmpty()) {
							m_Name = table_2.getValueAt(table_2.getSelectedRow(), columnIndex).toString();
						} else if (courseName.isEmpty()) {
							courseName = table_2.getValueAt(table_2.getSelectedRow(), columnIndex)
									.toString();
						} 
//						else if (level.isEmpty()) {
//							level = table_2.getValueAt(table_2.getSelectedRow(), columnIndex).toString();
//						} else if (sem.isEmpty()) {
//							sem = table_2.getValueAt(table_2.getSelectedRow(), columnIndex).toString();
//						}
						else if (creditValue.isEmpty()) {
							creditValue = table_2
									.getValueAt(table_2.getSelectedRow(), columnIndex).toString();
						}

					
					}
					
					moduleForm.getModuleNametextField().setText(m_Name);
					moduleForm.getCreditValueTextField().setText(creditValue);
					moduleForm.getCourseSelectedComboBox().setModel(new DefaultComboBoxModel(new String[] {courseName}));


				}
				
				
				
				
				
				
				
			}
		});
		scrollPane_4.setViewportView(table_2);
		table_2.setModel(ModuleDefaultTableModel);
		
		JPanel panel_1_1 = new JPanel();
		panel_1_1.setBackground(Color.BLACK);
		panel_1_1.setBounds(10, 6, 411, 41);
		panel_8.add(panel_1_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("Module Details");
		lblNewLabel_1_1.setForeground(Color.WHITE);
		lblNewLabel_1_1.setFont(new Font("Tahoma", Font.BOLD, 25));
		panel_1_1.add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_4 = new JLabel("Click on respective module row to update  text data");
		lblNewLabel_4.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel_4.setForeground(new Color(255, 0, 0));
		lblNewLabel_4.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4.setBounds(10, 46, 411, 24);
		panel_8.add(lblNewLabel_4);
		
		JLabel lblNewLabel_4_1 = new JLabel("Module ID :");
		lblNewLabel_4_1.setForeground(new Color(255, 255, 255));
		lblNewLabel_4_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_4_1.setBounds(10, 244, 109, 29);
		panel_8.add(lblNewLabel_4_1);
		
		moduleID = new JTextField();
		moduleID.setColumns(10);
		moduleID.setBounds(102, 246, 134, 29);
		panel_8.add(moduleID);
		
		JButton btnNewButton_3 = new JButton("Delete");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String moduleIDtext = moduleID.getText();
				if (moduleIDtext.length() > 0) {

					Statement statement = dbConn.getStatement();
					String deleteModuleQuery = "DELETE FROM `moduledata` WHERE ID='" + moduleIDtext + "'";
					
					try {
						int deleteModule = statement.executeUpdate(deleteModuleQuery);
						if(deleteModule==1) {
							JOptionPane.showMessageDialog(panel_8, "Module Data Deleted");
						}
						adminFrontend.showModule();
						}
					 catch (Exception e1) {
						// TODO: handle exception
						e1.printStackTrace();
					}

				}
			}
		});
		btnNewButton_3.setForeground(Color.WHITE);
		btnNewButton_3.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnNewButton_3.setBackground(Color.RED);
		btnNewButton_3.setBounds(246, 243, 114, 31);
		panel_8.add(btnNewButton_3);
		
		JPanel panel_9 = new JPanel();
		panel_9.setBackground(new Color(0, 0, 0));
		panel_6.add(panel_9, "name_114186172792800");
		cl_panel.show(panel_6, "name_114186172792800");
																						
		JScrollPane scrollPane_2 = new JScrollPane();
		scrollPane_2.setBounds(10, 10, 380, 139);
		panel_3.add(scrollPane_2);
																								
	    JLabel lblNewLabel_5 = new JLabel("Instructor Details");
	    lblNewLabel_5.setBackground(new Color(255, 255, 255));
		lblNewLabel_5.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_5.setHorizontalAlignment(SwingConstants.CENTER);
		scrollPane_2.setColumnHeaderView(lblNewLabel_5);
																										
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_2.setViewportView(scrollPane_1);
																												
		table = new JTable();
		scrollPane_1.setViewportView(table);
		table.setModel(teacherDefaultTableModel);
																														
		JPanel panel_5 = new JPanel();
		panel_5.setBounds(10, 192, 380, 179);
		panel_3.add(panel_5);
		panel_5.setLayout(null);
																																
		JScrollPane scrollPane_3 = new JScrollPane();
		scrollPane_3.setBounds(0, 67, 380, 62);
		panel_5.add(scrollPane_3);
																															
		table_1 = new JTable();
		table_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
		
				Object[] options = { "Generate", "Back" };
				int n = JOptionPane.showOptionDialog(null, "Do you want to Generate Report ? ",
						" ", JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null,
						options, options[0]);
				 String s_Name = "";
				 String course="";
				 String studnetId = "";
				 String semester="";
				 String number="";
				if (n == 0) {
					int id = Integer.parseInt(table_1.getValueAt(table_1.getSelectedRow(), 0).toString());
		
//					reportGenerate reportGenerate = new reportGenerate();
					
					
					
					int selectedRowNo = table_1.getSelectedRow();
					for (int columnIndex = 0; columnIndex < table_1.getColumnCount(); columnIndex++) {
						if (studnetId.isEmpty()) {
							studnetId = table_1.getValueAt(table_1.getSelectedRow(), columnIndex).toString();
						} else if (s_Name.isEmpty()) {
							s_Name = table_1.getValueAt(table_1.getSelectedRow(), columnIndex)
									.toString();
						} else if (course.isEmpty()) {
							course = table_1.getValueAt(table_1.getSelectedRow(), columnIndex).toString();
						} else if (semester.isEmpty()) {
							semester = table_1.getValueAt(table_1.getSelectedRow(), columnIndex).toString();
						}
						else if (number.isEmpty()) {
							number = table_1.getValueAt(table_1.getSelectedRow(), columnIndex).toString();
						}
					
					}

				}
					
					
					try {
						Statement statement = dbConn.getStatement();
						
						String selectQuery = "INSERT INTO `studentreport` (s_Name, mobileNumber, Percentage) SELECT studentName, studentUsername ,AVG(marks) FROM `submittedAssignment` WHERE studentUsername='"+ number +"'";
						System.out.println(selectQuery);
						int n1=statement.executeUpdate(selectQuery);
						if(n1==1) {
						JOptionPane.showMessageDialog(panel_5, "Report Saved into database!");
						}
						else {
							
						}
						

					} catch (SQLException e1) {
						JOptionPane.showMessageDialog(panel_5, "Error !! Duplicate entry");
						e1.printStackTrace();
					}
					
				
					
				
				
			
				
				
			}
		});
		scrollPane_3.setViewportView(table_1);
		table_1.setModel(searchStudentDefaultTableModel);
																																				
		JLabel lblNewLabel_7 = new JLabel("Student Name:");
		lblNewLabel_7.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel_7.setBounds(10, 10, 114, 27);
		panel_5.add(lblNewLabel_7);
																																						
		studentname = new JTextField();
		studentname.setBounds(134, 12, 143, 27);
		panel_5.add(studentname);
		studentname.setColumns(10);
																																								
		JButton btnNewButton = new JButton("Search");
		btnNewButton.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
		try {
			String s_name = studentname.getText();
			if (s_name.length() > 0) {

			Statement statement = dbConn.getStatement();
			String searchStudentNameQuery = "SELECT * FROM `studentdata` WHERE s_Name='" + s_name + "'";

			ResultSet resultSet;
			try {
			resultSet = statement.executeQuery(searchStudentNameQuery);
			// resultSet = statement.executeQuery(searchStudentDetailQuery);
			searchStudentDefaultTableModel.setRowCount(0);
			while (resultSet.next()) {
																																															
			String nameFromDb = resultSet.getString("s_Name");
			int sIDFromDb = resultSet.getInt("s_Id");
			String cEnrolledFromDb = resultSet.getString("c_Enrolled");
			String levelFromDb = resultSet.getString("s_Level");
			String SemFromDb = resultSet.getString("semester");
			String mobileNumberFromDB = resultSet.getString("mobileNumber");
			int cohortFromDb = resultSet.getInt("cohort");
			searchStudentDefaultTableModel.addRow(new Object[] { sIDFromDb, nameFromDb,
			cEnrolledFromDb, SemFromDb,mobileNumberFromDB, levelFromDb, cohortFromDb });
			}
			} catch (Exception e1) {
		// TODO: handle exception
			e1.printStackTrace();
			}

			}
			} catch (Exception e2) {
			// TODO: handle exception
				}

			}
				});
			btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 13));
			btnNewButton.setBounds(287, 11, 85, 26);
			panel_5.add(btnNewButton);
			
			JLabel lblNewLabel_6 = new JLabel("Click studnet table data to generate reports of searched Student");
			lblNewLabel_6.setHorizontalAlignment(SwingConstants.CENTER);
			lblNewLabel_6.setFont(new Font("Tahoma", Font.PLAIN, 9));
			lblNewLabel_6.setBounds(10, 129, 360, 25);
			panel_5.add(lblNewLabel_6);
			lblNewLabel_6.setForeground(new Color(255, 0, 0));
			
			JButton btnNewButton_2 = new JButton("View Students");
			btnNewButton_2.setFont(new Font("Tahoma", Font.BOLD, 10));
			btnNewButton_2.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					new viewStudent();
				}
			});
			btnNewButton_2.setBounds(10, 161, 114, 30);
			panel_3.add(btnNewButton_2);
			btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cl_panel.show(panel_6, "name_90567635080000");
				
				adminFrontend.showCourseTable();
			}
		});
		
		

		adminFrontend.showTeacherDataInJtableFromDb();
		frmAdmin.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmAdmin.setVisible(true);
	}
	
	public static void showCourseTable(){
		Statement statement = dbConn.getStatement();

		String selectQuery = "SELECT * FROM `coursedata`";

		ResultSet resultSet;;
		try {
			resultSet = statement.executeQuery(selectQuery);
			courseDefaultTableModel.setRowCount(0);
			while (resultSet.next()) {
				int IDFromDb=resultSet.getInt("ID");
				String nameFromDb = resultSet.getString("c_Name");
				String c_descFromDb = resultSet.getString("c_desc");
				String no_OfModuleFromDb = resultSet.getString("no_OfModule");
				String c_LevelFromDb = resultSet.getString("c_Level");
				String Length_OFCFromDb = resultSet.getString("Length_OfC");
				String creditValue = resultSet.getString("active_Status");
				courseDefaultTableModel.addRow(new Object[] { IDFromDb, nameFromDb, c_descFromDb,
						no_OfModuleFromDb, c_LevelFromDb, Length_OFCFromDb, creditValue });
			}
		} catch (Exception e1) {
			// TODO: handle exception
			e1.printStackTrace();
		}
	}
}
