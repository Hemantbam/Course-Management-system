package frontend;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.SpringLayout;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JPasswordField;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import java.awt.Color;
import javax.swing.SwingConstants;
import javax.swing.ImageIcon;

public class registration extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JTextField fullNametextField;
	private JTextField addressTextField;
	private JTextField mobileNotextField;
	private JPasswordField passwordField;
	private JPasswordField confirmPasswordField;
	private JComboBox enrollInCoursecomboBox;
	private JButton registerButton;
	private JLabel incorrectPasswordMessageLabel;
	Statement statement = dbConn.getStatement();
	private JPanel panel;
	private JLabel lblNewLabel_2;
	private JLabel lblNewLabel_3;
	private JLabel lblNewLabel_4;
	private JPanel panel_1;
	private JLabel lblNewLabel_5;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			registration dialog = new registration();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public registration() {
		setVisible(true);
		setTitle("Student Registration Form");
		setBounds(100, 100, 626, 457);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);

		JLabel lblNewLabel = new JLabel("FullName\r\n");
		lblNewLabel.setBounds(190, 48, 77, 14);
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 15));
		contentPanel.add(lblNewLabel);

		fullNametextField = new JTextField();
		fullNametextField.setBounds(277, 48, 320, 19);
		contentPanel.add(fullNametextField);
		fullNametextField.setColumns(10);

		JLabel lblAddress = new JLabel("Address\r\n");
		lblAddress.setBounds(189, 84, 78, 19);
		lblAddress.setFont(new Font("Tahoma", Font.PLAIN, 15));
		contentPanel.add(lblAddress);

		addressTextField = new JTextField();
		addressTextField.setBounds(277, 86, 320, 19);
		addressTextField.setColumns(10);
		contentPanel.add(addressTextField);

		JLabel lblMobileNumber = new JLabel("Mobile Number\r\n");
		lblMobileNumber.setBounds(190, 130, 102, 19);
		lblMobileNumber.setFont(new Font("Tahoma", Font.PLAIN, 15));
		contentPanel.add(lblMobileNumber);

		mobileNotextField = new JTextField();
		mobileNotextField.setBounds(319, 132, 278, 19);
		mobileNotextField.setColumns(10);
		contentPanel.add(mobileNotextField);

		enrollInCoursecomboBox = new JComboBox();
		enrollInCoursecomboBox.setBounds(319, 183, 186, 25);
		enrollInCoursecomboBox.setFont(new Font("Tahoma", Font.PLAIN, 15));

		// Get available courses(Course Name (only activated Course) from Course Table
		String Selectquery = "SELECT c_Name FROM `coursedata` WHERE active_Status = 'YES'";

//		String[] courseNames = new String[2];
//		int i = 0;
		try {
			ResultSet resultSet = statement.executeQuery(Selectquery);
			while(resultSet.next()) {
				enrollInCoursecomboBox.addItem(resultSet.getString("c_Name"));

			}

		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		
		//enrollInCoursecomboBox.setModel(new DefaultComboBoxModel(new String[] { "Select a Course", courseNames[0], courseNames[1] }));
		contentPanel.add(enrollInCoursecomboBox);

		JLabel lblEnrollInCourse = new JLabel("Enroll In Course");
		lblEnrollInCourse.setBounds(190, 186, 107, 19);
		lblEnrollInCourse.setFont(new Font("Tahoma", Font.PLAIN, 15));
		contentPanel.add(lblEnrollInCourse);

		passwordField = new JPasswordField();
		passwordField.setBounds(319, 244, 208, 19);
		contentPanel.add(passwordField);

		JLabel lblNewLabel_1 = new JLabel("Password");
		lblNewLabel_1.setBounds(190, 242, 62, 19);
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		contentPanel.add(lblNewLabel_1);

		JLabel lblNewLabel_1_1 = new JLabel("Confirm Password");
		lblNewLabel_1_1.setBounds(190, 293, 119, 19);
		lblNewLabel_1_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		contentPanel.add(lblNewLabel_1_1);

		confirmPasswordField = new JPasswordField();
		confirmPasswordField.setBounds(319, 295, 208, 19);
		contentPanel.add(confirmPasswordField);

		registerButton = new JButton("Register");
		registerButton.setBounds(277, 366, 119, 42);
		registerButton.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				String password = String.valueOf(passwordField.getPassword());
				String confirmPassword = String.valueOf(confirmPasswordField.getPassword());

				if (!password.equals(confirmPassword)) {
					incorrectPasswordMessageLabel.setVisible(true);
				} else {
					incorrectPasswordMessageLabel.setVisible(false);
				}

				// the username will be the same value as mobilenumber 
				// UserType - Student,Admin,Instructor
				// Insert query in useracccount Table
				
				
				
				String userType = "Student";
				String fullName = fullNametextField.getText().trim();
				String address = addressTextField.getText().trim();
				String mobileNo = mobileNotextField.getText().trim();

				String insertQueryInUserAccount = "INSERT INTO `useraccount` (`Name`, `Address`, `mobileNumber`, `userType`, `password`) "
						+ "VALUES ('" + fullName + "', '" + address + "', '" + mobileNo + "', '" + userType
						+ "', '" + confirmPassword + "')";
				
				try {
					statement.execute(insertQueryInUserAccount);
					// Get the userId from UserAccount table
					String selectQueryFromUser = "SELECT ID,Name FROM `useraccount` WHERE mobileNumber ='" + mobileNo+ "'";
					ResultSet resultSet = statement.executeQuery(selectQueryFromUser);

					resultSet.next();
					int ID = resultSet.getInt("ID");
					String Name = resultSet.getString("Name");
					// Get the enrolled course
					String enrolledCourse = enrollInCoursecomboBox.getModel().getSelectedItem().toString();
					// Insert query into Student table
					String insertQueryForStudent = "INSERT INTO `studentdata` (`user_Id`,`s_Name`, `c_Enrolled`, `Assignment`, `Report`, `s_Level`, `Semester`, `Cohort`,`mobileNumber`) "
							+ "VALUES (" + ID + ",'"+ Name +"', '" + enrolledCourse
							+ "', 1, 1, 'Level 5', '1st Semester', 8,'"+ mobileNo +"')";
					
					statement.execute(insertQueryForStudent);
					JOptionPane.showMessageDialog(contentPanel, "Successfully registered and saved in the database");
					
				
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
				
				
				dispose();
			
				
			}
		});
		registerButton.setFont(new Font("Tahoma", Font.PLAIN, 16));
		contentPanel.add(registerButton);

		incorrectPasswordMessageLabel = new JLabel("Password didn't match!");
		incorrectPasswordMessageLabel.setBounds(339, 321, 147, 17);
		incorrectPasswordMessageLabel.setFont(new Font("Tahoma", Font.PLAIN, 14));
		incorrectPasswordMessageLabel.setForeground(new Color(255, 0, 0));
		incorrectPasswordMessageLabel.setVisible(false);
		contentPanel.add(incorrectPasswordMessageLabel);
		
		panel = new JPanel();
		panel.setLayout(null);
		panel.setBackground(new Color(64, 0, 128));
		panel.setBounds(0, 0, 170, 424);
		contentPanel.add(panel);
		
		lblNewLabel_2 = new JLabel("Register Student");
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2.setForeground(Color.WHITE);
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 17));
		lblNewLabel_2.setBounds(10, 207, 150, 47);
		panel.add(lblNewLabel_2);
		
		lblNewLabel_3 = new JLabel("CMS");
		lblNewLabel_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_3.setForeground(Color.WHITE);
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 30));
		lblNewLabel_3.setBounds(10, 10, 150, 78);
		panel.add(lblNewLabel_3);
		
		lblNewLabel_4 = new JLabel("");
		lblNewLabel_4.setIcon(new ImageIcon(registration.class.getResource("/Image/icon form.png")));
		lblNewLabel_4.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4.setBounds(10, 78, 150, 130);
		panel.add(lblNewLabel_4);
		
		panel_1 = new JPanel();
		panel_1.setBackground(Color.BLACK);
		panel_1.setBounds(173, 0, 424, 38);
		contentPanel.add(panel_1);
		
		lblNewLabel_5 = new JLabel("Registration");
		lblNewLabel_5.setForeground(Color.WHITE);
		lblNewLabel_5.setFont(new Font("Tahoma", Font.BOLD, 25));
		panel_1.add(lblNewLabel_5);
	}
}