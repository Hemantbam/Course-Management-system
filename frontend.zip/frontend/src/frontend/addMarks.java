package frontend;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import java.awt.Color;
import javax.swing.border.MatteBorder;

public class addMarks extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JTextField addMarksText;
	private static JTextField assignmentId;
	private static JTextField nametextField;

	/**
	 * Launch the application.
	 */
	
	
	
	public static void main(String[] args) {
		try {
			addMarks dialog = new addMarks();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}


	public static JTextField getAssignmentId() {
		return assignmentId;
	}


	public static JTextField getNametextField() {
		return nametextField;
	}
	
	/**
	 * Create the dialog.
	 */
	public addMarks() {
		setVisible(true);
		setTitle("Add Marks");
		setBounds(100, 100, 334, 241);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBackground(new Color(64, 0, 128));
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		
		JButton btnNewButton = new JButton("Add");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String a_id = getAssignmentId().getText().trim();
				Statement statement2 = dbConn.getStatement();
				String marksset = addMarksText.getText().trim();
				String addMarksQuery=" UPDATE `submittedassignment` SET `marks`='"+marksset+"' Where id='"+ a_id + "'" ;
				System.out.println(addMarksQuery);
				try {
					
					int updateSuccess = statement2.executeUpdate(addMarksQuery);
					if(updateSuccess == 1) {
						JOptionPane.showMessageDialog(contentPanel, "Marks Added Successfully!");
					}
					
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				dispose();
			}
		});
		
		addMarksText = new JTextField();
		addMarksText.setBorder(new MatteBorder(1, 1, 1, 1, (Color) new Color(0, 0, 0)));
		addMarksText.setBounds(127, 130, 39, 32);
		contentPanel.add(addMarksText);
		addMarksText.setColumns(10);
		btnNewButton.setBounds(176, 132, 67, 27);
		contentPanel.add(btnNewButton);
		
		JLabel lblNewLabel = new JLabel("Add Marks");
		lblNewLabel.setForeground(new Color(255, 255, 255));
		lblNewLabel.setBackground(new Color(0, 0, 0));
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(10, 10, 300, 19);
		contentPanel.add(lblNewLabel);
		
		JLabel usernameLabel = new JLabel("Aassignment ID :");
		usernameLabel.setFont(new Font("Tahoma", Font.PLAIN, 12));
		usernameLabel.setForeground(new Color(255, 255, 255));
		usernameLabel.setBounds(21, 55, 107, 27);
		contentPanel.add(usernameLabel);
		
		JLabel lblNewLabel_1_2 = new JLabel("Studnet Name :");
		lblNewLabel_1_2.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel_1_2.setForeground(new Color(255, 255, 255));
		lblNewLabel_1_2.setBounds(20, 91, 97, 27);
		contentPanel.add(lblNewLabel_1_2);
		
		JLabel nameTextForm = new JLabel("");
		nameTextForm.setBounds(153, 95, 90, 19);
		contentPanel.add(nameTextForm);
		
		assignmentId = new JTextField();
		assignmentId.setEditable(false);
		assignmentId.setBounds(127, 59, 116, 19);
		contentPanel.add(assignmentId);
		assignmentId.setColumns(10);
		
		nametextField = new JTextField();
		nametextField.setEditable(false);
		nametextField.setColumns(10);
		nametextField.setBounds(127, 96, 116, 19);
		contentPanel.add(nametextField);
		
		JLabel lblNewLabel_1 = new JLabel("Marks :");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel_1.setForeground(new Color(255, 255, 255));
		lblNewLabel_1.setBounds(61, 138, 67, 13);
		contentPanel.add(lblNewLabel_1);
	}
}
